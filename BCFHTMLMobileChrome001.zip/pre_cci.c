# 1 "c:\\adminplanit\\vugen scripts\\bcfhtmlmobilechrome001\\\\combined_BCFHTMLMobileChrome001.c"
# 1 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h" 1
 
 












 











# 103 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"






















































		


		typedef unsigned size_t;
	
	
        
	

















	

 



















 
 
 
 
 


 
 
 
 
 
 














int     lr_start_transaction   (char * transaction_name);
int lr_start_sub_transaction          (char * transaction_name, char * trans_parent);
long lr_start_transaction_instance    (char * transaction_name, long parent_handle);
int   lr_start_cross_vuser_transaction		(char * transaction_name, char * trans_id_param); 



int     lr_end_transaction     (char * transaction_name, int status);
int lr_end_sub_transaction            (char * transaction_name, int status);
int lr_end_transaction_instance       (long transaction, int status);
int   lr_end_cross_vuser_transaction	(char * transaction_name, char * trans_id_param, int status);


 
typedef char* lr_uuid_t;
 



lr_uuid_t lr_generate_uuid();

 


int lr_generate_uuid_free(lr_uuid_t uuid);

 



int lr_generate_uuid_on_buf(lr_uuid_t buf);

   
# 273 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
int lr_start_distributed_transaction  (char * transaction_name, lr_uuid_t correlator, long timeout  );

   







int lr_end_distributed_transaction  (lr_uuid_t correlator, int status);


double lr_stop_transaction            (char * transaction_name);
double lr_stop_transaction_instance   (long parent_handle);


void lr_resume_transaction           (char * trans_name);
void lr_resume_transaction_instance  (long trans_handle);


int lr_update_transaction            (const char *trans_name);


 
void lr_wasted_time(long time);


 
int lr_set_transaction(const char *name, double duration, int status);
 
long lr_set_transaction_instance(const char *name, double duration, int status, long parent_handle);


int   lr_user_data_point                      (char *, double);
long lr_user_data_point_instance                   (char *, double, long);
 



int lr_user_data_point_ex(const char *dp_name, double value, int log_flag);
long lr_user_data_point_instance_ex(const char *dp_name, double value, long parent_handle, int log_flag);


int lr_transaction_add_info      (const char *trans_name, char *info);
int lr_transaction_instance_add_info   (long trans_handle, char *info);
int lr_dpoint_add_info           (const char *dpoint_name, char *info);
int lr_dpoint_instance_add_info        (long dpoint_handle, char *info);


double lr_get_transaction_duration       (char * trans_name);
double lr_get_trans_instance_duration    (long trans_handle);
double lr_get_transaction_think_time     (char * trans_name);
double lr_get_trans_instance_think_time  (long trans_handle);
double lr_get_transaction_wasted_time    (char * trans_name);
double lr_get_trans_instance_wasted_time (long trans_handle);
int    lr_get_transaction_status		 (char * trans_name);
int	   lr_get_trans_instance_status		 (long trans_handle);

 



int lr_set_transaction_status(int status);

 



int lr_set_transaction_status_by_name(int status, const char *trans_name);
int lr_set_transaction_instance_status(int status, long trans_handle);


typedef void* merc_timer_handle_t;
 

merc_timer_handle_t lr_start_timer();
double lr_end_timer(merc_timer_handle_t timer_handle);


 
 
 
 
 
 











 



int   lr_rendezvous  (char * rendezvous_name);
 




int   lr_rendezvous_ex (char * rendezvous_name);



 
 
 
 
 
char *lr_get_vuser_ip (void);
void   lr_whoami (int *vuser_id, char ** sgroup, int *scid);
char *	  lr_get_host_name (void);
char *	  lr_get_master_host_name (void);

 
long     lr_get_attrib_long	(char * attr_name);
char *   lr_get_attrib_string	(char * attr_name);
double   lr_get_attrib_double      (char * attr_name);

char * lr_paramarr_idx(const char * paramArrayName, unsigned int index);
char * lr_paramarr_random(const char * paramArrayName);
int    lr_paramarr_len(const char * paramArrayName);

int	lr_param_unique(const char * paramName);
int lr_param_sprintf(const char * paramName, const char * format, ...);


 
 
static void *ci_this_context = 0;






 








void lr_continue_on_error (int lr_continue);
char *   lr_decrypt (const char *EncodedString);


 
 
 
 
 
 



 







 















void   lr_abort (void);
void lr_exit(int exit_option, int exit_status);
void lr_abort_ex (unsigned long flags);

void   lr_peek_events (void);


 
 
 
 
 


void   lr_think_time (double secs);

 


void lr_force_think_time (double secs);


 
 
 
 
 



















int   lr_msg (char * fmt, ...);
int   lr_debug_message (unsigned int msg_class,
									    char * format,
										...);
# 512 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
void   lr_new_prefix (int type,
                                 char * filename,
                                 int line);
# 515 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
int   lr_log_message (char * fmt, ...);
int   lr_message (char * fmt, ...);
int   lr_error_message (char * fmt, ...);
int   lr_output_message (char * fmt, ...);
int   lr_vuser_status_message (char * fmt, ...);
int   lr_error_message_without_fileline (char * fmt, ...);
int   lr_fail_trans_with_error (char * fmt, ...);

 
 
 
 
 
# 539 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"

 
 
 
 
 





int   lr_next_row ( char * table);
int lr_advance_param ( char * param);



														  
														  

														  
														  

													      
 


char *   lr_eval_string (char * str);
int   lr_eval_string_ext (const char *in_str,
                                     unsigned long const in_len,
                                     char ** const out_str,
                                     unsigned long * const out_len,
                                     unsigned long const options,
                                     const char *file,
								     long const line);
# 573 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
void   lr_eval_string_ext_free (char * * pstr);

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
int lr_param_increment (char * dst_name,
                              char * src_name);
# 596 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"













											  
											  

											  
											  
											  

int	  lr_save_var (char *              param_val,
							  unsigned long const param_val_len,
							  unsigned long const options,
							  char *			  param_name);
# 620 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
int   lr_save_string (const char * param_val, const char * param_name);



int   lr_set_custom_error_message (const char * param_val, ...);

int   lr_remove_custom_error_message ();


int   lr_free_parameter (const char * param_name);
int   lr_save_int (const int param_val, const char * param_name);
int   lr_save_timestamp (const char * tmstampParam, ...);
int   lr_save_param_regexp (const char *bufferToScan, unsigned int bufSize, ...);

int   lr_convert_double_to_integer (const char *source_param_name, const char * target_param_name);
int   lr_convert_double_to_double (const char *source_param_name, const char *format_string, const char * target_param_name);

 
 
 
 
 
 
# 699 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
void   lr_save_datetime (const char *format, int offset, const char *name);









 











 
 
 
 
 






 



char * lr_error_context_get_entry (char * key);

 



long   lr_error_context_get_error_id (void);


 
 
 

int lr_table_get_rows_num (char * param_name);

int lr_table_get_cols_num (char * param_name);

char * lr_table_get_cell_by_col_index (char * param_name, int row, int col);

char * lr_table_get_cell_by_col_name (char * param_name, int row, const char* col_name);

int lr_table_get_column_name_by_index (char * param_name, int col, 
											char * * const col_name,
											size_t * col_name_len);
# 760 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"

int lr_table_get_column_name_by_index_free (char * col_name);

 
 
 
 
# 775 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
int   lr_zip (const char* param1, const char* param2);
int   lr_unzip (const char* param1, const char* param2);

 
 
 
 
 
 
 
 

 
 
 
 
 
 
int   lr_param_substit (char * file,
                                   int const line,
                                   char * in_str,
                                   size_t const in_len,
                                   char * * const out_str,
                                   size_t * const out_len);
# 799 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
void   lr_param_substit_free (char * * pstr);


 
# 811 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"





char *   lrfnc_eval_string (char * str,
                                      char * file_name,
                                      long const line_num);
# 819 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"


int   lrfnc_save_string ( const char * param_val,
                                     const char * param_name,
                                     const char * file_name,
                                     long const line_num);
# 825 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"

int   lrfnc_free_parameter (const char * param_name );







typedef struct _lr_timestamp_param
{
	int iDigits;
}lr_timestamp_param;

extern const lr_timestamp_param default_timestamp_param;

int   lrfnc_save_timestamp (const char * param_name, const lr_timestamp_param* time_param);

int lr_save_searched_string(char * buffer, long buf_size, unsigned int occurrence,
			    char * search_string, int offset, unsigned int param_val_len, 
			    char * param_name);

 
char *   lr_string (char * str);

 
# 926 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"

int   lr_save_value (char * param_val,
                                unsigned long const param_val_len,
                                unsigned long const options,
                                char * param_name,
                                char * file_name,
                                long const line_num);
# 933 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"


 
 
 
 
 











int   lr_printf (char * fmt, ...);
 
int   lr_set_debug_message (unsigned int msg_class,
                                       unsigned int swtch);
# 955 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
unsigned int   lr_get_debug_message (void);


 
 
 
 
 

void   lr_double_think_time ( double secs);
void   lr_usleep (long);


 
 
 
 
 
 




int *   lr_localtime (long offset);


int   lr_send_port (long port);


# 1031 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"



struct _lr_declare_identifier{
	char signature[24];
	char value[128];
};

int   lr_pt_abort (void);

void vuser_declaration (void);






# 1060 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"


# 1072 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
















 
 
 
 
 







int    _lr_declare_transaction   (char * transaction_name);


 
 
 
 
 







int   _lr_declare_rendezvous  (char * rendezvous_name);

 
 
 
 
 


typedef int PVCI;






typedef int VTCERR;









PVCI   vtc_connect(char * servername, int portnum, int options);
VTCERR   vtc_disconnect(PVCI pvci);
VTCERR   vtc_get_last_error(PVCI pvci);
VTCERR   vtc_query_column(PVCI pvci, char * columnName, int columnIndex, char * *outvalue);
VTCERR   vtc_query_row(PVCI pvci, int rowIndex, char * **outcolumns, char * **outvalues);
VTCERR   vtc_send_message(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_if_unique(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_row1(PVCI pvci, char * columnNames, char * messages, char * delimiter, unsigned char sendflag, unsigned short *outUpdates);
VTCERR   vtc_update_message(PVCI pvci, char * column, int index , char * message, unsigned short *outRc);
VTCERR   vtc_update_message_ifequals(PVCI pvci, char * columnName, int index,	char * message, char * ifmessage, unsigned short 	*outRc);
VTCERR   vtc_update_row1(PVCI pvci, char * columnNames, int index , char * messages, char * delimiter, unsigned short *outUpdates);
VTCERR   vtc_retrieve_message(PVCI pvci, char * column, char * *outvalue);
VTCERR   vtc_retrieve_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues);
VTCERR   vtc_retrieve_row(PVCI pvci, char * **outcolumns, char * **outvalues);
VTCERR   vtc_rotate_message(PVCI pvci, char * column, char * *outvalue, unsigned char sendflag);
VTCERR   vtc_rotate_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_rotate_row(PVCI pvci, char * **outcolumns, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_increment(PVCI pvci, char * column, int index , int incrValue, int *outValue);
VTCERR   vtc_clear_message(PVCI pvci, char * column, int index , unsigned short *outRc);
VTCERR   vtc_clear_column(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_ensure_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_drop_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_clear_row(PVCI pvci, int rowIndex, unsigned short *outRc);
VTCERR   vtc_create_column(PVCI pvci, char * column,unsigned short *outRc);
VTCERR   vtc_column_size(PVCI pvci, char * column, int *size);
void   vtc_free(char * msg);
void   vtc_free_list(char * *msglist);

VTCERR   lrvtc_connect(char * servername, int portnum, int options);
VTCERR   lrvtc_disconnect();
VTCERR   lrvtc_query_column(char * columnName, int columnIndex);
VTCERR   lrvtc_query_row(int columnIndex);
VTCERR   lrvtc_send_message(char * columnName, char * message);
VTCERR   lrvtc_send_if_unique(char * columnName, char * message);
VTCERR   lrvtc_send_row1(char * columnNames, char * messages, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_update_message(char * columnName, int index , char * message);
VTCERR   lrvtc_update_message_ifequals(char * columnName, int index, char * message, char * ifmessage);
VTCERR   lrvtc_update_row1(char * columnNames, int index , char * messages, char * delimiter);
VTCERR   lrvtc_retrieve_message(char * columnName);
VTCERR   lrvtc_retrieve_messages1(char * columnNames, char * delimiter);
VTCERR   lrvtc_retrieve_row();
VTCERR   lrvtc_rotate_message(char * columnName, unsigned char sendflag);
VTCERR   lrvtc_rotate_messages1(char * columnNames, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_rotate_row(unsigned char sendflag);
VTCERR   lrvtc_increment(char * columnName, int index , int incrValue);
VTCERR   lrvtc_noop();
VTCERR   lrvtc_clear_message(char * columnName, int index);
VTCERR   lrvtc_clear_column(char * columnName); 
VTCERR   lrvtc_ensure_index(char * columnName); 
VTCERR   lrvtc_drop_index(char * columnName); 
VTCERR   lrvtc_clear_row(int rowIndex);
VTCERR   lrvtc_create_column(char * columnName);
VTCERR   lrvtc_column_size(char * columnName);



 
 
 
 
 

 
int lr_enable_ip_spoofing();
int lr_disable_ip_spoofing();


 




int lr_convert_string_encoding(char * sourceString, char * fromEncoding, char * toEncoding, char * paramName);
int lr_read_file(const char *filename, const char *outputParam, int continueOnError);


 
int lr_db_connect (char * pFirstArg, ...);
int lr_db_disconnect (char * pFirstArg,	...);
int lr_db_executeSQLStatement (char * pFirstArg, ...);
int lr_db_dataset_action(char * pFirstArg, ...);
int lr_checkpoint(char * pFirstArg,	...);
int lr_db_getvalue(char * pFirstArg, ...);







 
 



















# 1 "c:\\adminplanit\\vugen scripts\\bcfhtmlmobilechrome001\\\\combined_BCFHTMLMobileChrome001.c" 2

# 1 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/SharedParameter.h" 1



 
 
 
 
# 100 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/SharedParameter.h"






typedef int PVCI2;






typedef int VTCERR2;


 
 
 

 
extern PVCI2    vtc_connect(char *servername, int portnum, int options);
extern VTCERR2  vtc_disconnect(PVCI2 pvci);
extern VTCERR2  vtc_get_last_error(PVCI2 pvci);

 
extern VTCERR2  vtc_query_column(PVCI2 pvci, char *columnName, int columnIndex, char **outvalue);
extern VTCERR2  vtc_query_row(PVCI2 pvci, int columnIndex, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_send_message(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_if_unique(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_row1(PVCI2 pvci, char *columnNames, char *messages, char *delimiter,  unsigned char sendflag, unsigned short *outUpdates);
extern VTCERR2  vtc_update_message(PVCI2 pvci, char *column, int index , char *message, unsigned short *outRc);
extern VTCERR2  vtc_update_message_ifequals(PVCI2 pvci, char	*columnName, int index,	char *message, char	*ifmessage,	unsigned short 	*outRc);
extern VTCERR2  vtc_update_row1(PVCI2 pvci, char *columnNames, int index , char *messages, char *delimiter, unsigned short *outUpdates);
extern VTCERR2  vtc_retrieve_message(PVCI2 pvci, char *column, char **outvalue);
extern VTCERR2  vtc_retrieve_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues);
extern VTCERR2  vtc_retrieve_row(PVCI2 pvci, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_rotate_message(PVCI2 pvci, char *column, char **outvalue, unsigned char sendflag);
extern VTCERR2  vtc_rotate_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues, unsigned char sendflag);
extern VTCERR2  vtc_rotate_row(PVCI2 pvci, char ***outcolumns, char ***outvalues, unsigned char sendflag);
extern VTCERR2	vtc_increment(PVCI2 pvci, char *column, int index , int incrValue, int *outValue);
extern VTCERR2  vtc_clear_message(PVCI2 pvci, char *column, int index , unsigned short *outRc);
extern VTCERR2  vtc_clear_column(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_clear_row(PVCI2 pvci, int rowIndex, unsigned short *outRc);

extern VTCERR2  vtc_create_column(PVCI2 pvci, char *column,unsigned short *outRc);
extern VTCERR2  vtc_column_size(PVCI2 pvci, char *column, int *size);
extern VTCERR2  vtc_ensure_index(PVCI2 pvci, char *column, unsigned short *outRc);
extern VTCERR2  vtc_drop_index(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_noop(PVCI2 pvci);

 
extern void vtc_free(char *msg);
extern void vtc_free_list(char **msglist);

 


 




 




















 




 
 
 

extern VTCERR2  lrvtc_connect(char *servername, int portnum, int options);
extern VTCERR2  lrvtc_disconnect();
extern VTCERR2  lrvtc_query_column(char *columnName, int columnIndex);
extern VTCERR2  lrvtc_query_row(int columnIndex);
extern VTCERR2  lrvtc_send_message(char *columnName, char *message);
extern VTCERR2  lrvtc_send_if_unique(char *columnName, char *message);
extern VTCERR2  lrvtc_send_row1(char *columnNames, char *messages, char *delimiter,  unsigned char sendflag);
extern VTCERR2  lrvtc_update_message(char *columnName, int index , char *message);
extern VTCERR2  lrvtc_update_message_ifequals(char *columnName, int index, char 	*message, char *ifmessage);
extern VTCERR2  lrvtc_update_row1(char *columnNames, int index , char *messages, char *delimiter);
extern VTCERR2  lrvtc_retrieve_message(char *columnName);
extern VTCERR2  lrvtc_retrieve_messages1(char *columnNames, char *delimiter);
extern VTCERR2  lrvtc_retrieve_row();
extern VTCERR2  lrvtc_rotate_message(char *columnName, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_messages1(char *columnNames, char *delimiter, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_row(unsigned char sendflag);
extern VTCERR2  lrvtc_increment(char *columnName, int index , int incrValue);
extern VTCERR2  lrvtc_clear_message(char *columnName, int index);
extern VTCERR2  lrvtc_clear_column(char *columnName);
extern VTCERR2  lrvtc_clear_row(int rowIndex);
extern VTCERR2  lrvtc_create_column(char *columnName);
extern VTCERR2  lrvtc_column_size(char *columnName);
extern VTCERR2  lrvtc_ensure_index(char *columnName);
extern VTCERR2  lrvtc_drop_index(char *columnName);

extern VTCERR2  lrvtc_noop();

 
 
 

                               


 
 
 





















# 2 "c:\\adminplanit\\vugen scripts\\bcfhtmlmobilechrome001\\\\combined_BCFHTMLMobileChrome001.c" 2

# 1 "globals.h" 1



 
 

# 1 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/web_api.h" 1







# 1 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/as_web.h" 1



























































 




 



 











 





















 
 
 

  int
	web_add_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_add_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
	
  int
	web_add_auto_header(
		const char *		mpszHeader,
		const char *		mpszValue);

  int
	web_add_header(
		const char *		mpszHeader,
		const char *		mpszValue);
  int
	web_add_cookie(
		const char *		mpszCookie);
  int
	web_cleanup_auto_headers(void);
  int
	web_cleanup_cookies(void);
  int
	web_concurrent_end(
		const char * const	mpszReserved,
										 
		...								 
	);
  int
	web_concurrent_start(
		const char * const	mpszConcurrentGroupName,
										 
										 
		...								 
										 
	);
  int
	web_create_html_param(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim);
  int
	web_create_html_param_ex(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim,
		const char *		mpszNum);
  int
	web_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_disable_keep_alive(void);
  int
	web_enable_keep_alive(void);
  int
	web_find(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_get_int_property(
		const int			miHttpInfoType);
  int
	web_image(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_image_check(
		const char *		mpszName,
		...);
  int
	web_java_check(
		const char *		mpszName,
		...);
  int
	web_link(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

	
  int
	web_global_verification(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
  int
	web_reg_find(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
				
  int
	web_reg_save_param(
		const char *		mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 

  int
	web_convert_param(
		const char * 		mpszParamName, 
										 
		...);							 
										 
										 


										 

										 
  int
	web_remove_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
				
  int
	web_remove_auto_header(
		const char *		mpszHeaderName,
		...);							 
										 



  int
	web_remove_cookie(
		const char *		mpszCookie);

  int
	web_save_header(
		const char *		mpszType,	 
		const char *		mpszName);	 
  int
	web_set_certificate(
		const char *		mpszIndex);
  int
	web_set_certificate_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_set_connections_limit(
		const char *		mpszLimit);
  int
	web_set_max_html_param_len(
		const char *		mpszLen);
  int
	web_set_max_retries(
		const char *		mpszMaxRetries);
  int
	web_set_proxy(
		const char *		mpszProxyHost);
  int
	web_set_pac(
		const char *		mpszPacUrl);
  int
	web_set_proxy_bypass(
		const char *		mpszBypass);
  int
	web_set_secure_proxy(
		const char *		mpszProxyHost);
  int
	web_set_sockets_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue
	);
  int
	web_set_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue,
		...								 
	);
  int
	web_set_timeout(
		const char *		mpszWhat,
		const char *		mpszTimeout);
  int
	web_set_user(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);

  int
	web_sjis_to_euc_param(
		const char *		mpszParamName,
										 
		const char *		mpszParamValSjis);
										 

  int
	web_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_submit_form(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	spdy_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_set_proxy_bypass_local(
		const char * mpszNoLocal
		);

  int 
	web_cache_cleanup(void);

  int
	web_create_html_query(
		const char* mpszStartQuery,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_create_radio_button_param(
		const char *NameFiled,
		const char *NameAndVal,
		const char *ParamName
		);

  int
	web_convert_from_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										
  int
	web_convert_to_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_ex(
		const char * mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_xpath(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_json(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_regexp(
		 const char * mpszParamName,
		 ...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_run(
		const char * mpszCode,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_reset(void);

  int
	web_convert_date_param(
		const char * 		mpszParamName,
		...);










# 769 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/as_web.h"


# 782 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/as_web.h"



























# 820 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/as_web.h"

 
 
 


  int
	FormSubmit(
		const char *		mpszFormName,
		...);
  int
	InitWebVuser(void);
  int
	SetUser(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);
  int
	TerminateWebVuser(void);
  int
	URL(
		const char *		mpszUrlName);
























# 888 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/as_web.h"


  int
	web_rest(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 

  int
web_stream_open(
	const char *		mpszArg1,
	...
);
  int
	web_stream_wait(
		const char *		mpszArg1,
		...
	);

  int
	web_stream_close(
		const char *		mpszArg1,
		...
	);

  int
web_stream_play(
	const char *		mpszArg1,
	...
	);

  int
web_stream_pause(
	const char *		mpszArg1,
	...
	);

  int
web_stream_seek(
	const char *		mpszArg1,
	...
	);

  int
web_stream_get_param_int(
	const char*			mpszStreamID,
	const int			miStateType
	);

  double
web_stream_get_param_double(
	const char*			mpszStreamID,
	const int			miStateType
	);

  int
web_stream_get_param_string(
	const char*			mpszStreamID,
	const int			miStateType,
	const char*			mpszParameterName
	);

  int
web_stream_set_param_int(
	const char*			mpszStreamID,
	const int			miStateType,
	const int			miStateValue
	);

  int
web_stream_set_param_double(
	const char*			mpszStreamID,
	const int			miStateType,
	const double		mdfStateValue
	);

 
 
 






# 9 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/web_api.h" 2

















 







 














  int
	web_reg_add_cookie(
		const char *		mpszCookie,
		...);							 
										 

  int
	web_report_data_point(
		const char *		mpszEventType,
		const char *		mpszEventName,
		const char *		mpszDataPointName,
		const char *		mpszLAST);	 
										 
										 
										 

  int
	web_text_link(
		const char *		mpszStepName,
		...);

  int
	web_element(
		const char *		mpszStepName,
		...);

  int
	web_image_link(
		const char *		mpszStepName,
		...);

  int
	web_static_image(
		const char *		mpszStepName,
		...);

  int
	web_image_submit(
		const char *		mpszStepName,
		...);

  int
	web_button(
		const char *		mpszStepName,
		...);

  int
	web_edit_field(
		const char *		mpszStepName,
		...);

  int
	web_radio_group(
		const char *		mpszStepName,
		...);

  int
	web_check_box(
		const char *		mpszStepName,
		...);

  int
	web_list(
		const char *		mpszStepName,
		...);

  int
	web_text_area(
		const char *		mpszStepName,
		...);

  int
	web_map_area(
		const char *		mpszStepName,
		...);

  int
	web_eval_java_script(
		const char *		mpszStepName,
		...);

  int
	web_reg_dialog(
		const char *		mpszArg1,
		...);

  int
	web_reg_cross_step_download(
		const char *		mpszArg1,
		...);

  int
	web_browser(
		const char *		mpszStepName,
		...);

  int
	web_control(
		const char *		mpszStepName,
		...);

  int
	web_set_rts_key(
		const char *		mpszArg1,
		...);

  int
	web_save_param_length(
		const char * 		mpszParamName,
		...);

  int
	web_save_timestamp_param(
		const char * 		mpszParamName,
		...);

  int
	web_load_cache(
		const char *		mpszStepName,
		...);							 
										 

  int
	web_dump_cache(
		const char *		mpszStepName,
		...);							 
										 
										 

  int
	web_reg_find_in_log(
		const char *		mpszArg1,
		...);							 
										 
										 

  int
	web_get_sockets_info(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 

  int
	web_add_cookie_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

  int
	web_hook_java_script(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

 
 
 
 
 
 
 
 
 
 
 
 
  int
	web_reg_async_attributes(
		const char *		mpszArg,
		...
	);

 
 
 
 
 
 
  int
	web_sync(
		 const char *		mpszArg1,
		 ...
	);

 
 
 
 
  int
	web_stop_async(
		const char *		mpszArg1,
		...
	);

 
 
 
 
 

 
 
 

typedef enum WEB_ASYNC_CB_RC_ENUM_T
{
	WEB_ASYNC_CB_RC_OK,				 

	WEB_ASYNC_CB_RC_ABORT_ASYNC_NOT_ERROR,
	WEB_ASYNC_CB_RC_ABORT_ASYNC_ERROR,
										 
										 
										 
										 
	WEB_ASYNC_CB_RC_ENUM_COUNT
} WEB_ASYNC_CB_RC_ENUM;

 
 
 

typedef enum WEB_CONVERS_CB_CALL_REASON_ENUM_T
{
	WEB_CONVERS_CB_CALL_REASON_BUFFER_RECEIVED,
	WEB_CONVERS_CB_CALL_REASON_END_OF_TASK,

	WEB_CONVERS_CB_CALL_REASON_ENUM_COUNT
} WEB_CONVERS_CB_CALL_REASON_ENUM;

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

typedef
int														 
	(*RequestCB_t)();

typedef
int														 
	(*ResponseBodyBufferCB_t)(
		  const char *		aLastBufferStr,
		  int				aLastBufferLen,
		  const char *		aAccumulatedStr,
		  int				aAccumulatedLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseCB_t)(
		  const char *		aResponseHeadersStr,
		  int				aResponseHeadersLen,
		  const char *		aResponseBodyStr,
		  int				aResponseBodyLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseHeadersCB_t)(
		  int				aHttpStatusCode,
		  const char *		aAccumulatedHeadersStr,
		  int				aAccumulatedHeadersLen);



 
 
 

typedef enum WEB_CONVERS_UTIL_RC_ENUM_T
{
	WEB_CONVERS_UTIL_RC_OK,
	WEB_CONVERS_UTIL_RC_CONVERS_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_TASK_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_UNAVIALABLE,
	WEB_CONVERS_UTIL_RC_INVALID_ARGUMENT,

	WEB_CONVERS_UTIL_RC_ENUM_COUNT
} WEB_CONVERS_UTIL_RC_ENUM;

 
 
 

  int					 
	web_util_set_request_url(
		  const char *		aUrlStr);

  int					 
	web_util_set_request_body(
		  const char *		aRequestBodyStr);

  int					 
	web_util_set_formatted_request_body(
		  const char *		aRequestBodyStr);


 
 
 
 
 

 
 
 
 
 

 
 
 
 
 
 
 
 

 
 
  int
web_websocket_connect(
		 const char *	mpszArg1,
		 ...
		 );


 
 
 
 
 																						
  int
web_websocket_send(
	   const char *		mpszArg1,
		...
	   );

 
 
 
 
 
 
  int
web_websocket_close(
		const char *	mpszArg1,
		...
		);

 
typedef
void														
(*OnOpen_t)(
			  const char* connectionID,  
			  const char * responseHeader,  
			  int length  
);

typedef
void														
(*OnMessage_t)(
	  const char* connectionID,  
	  int isbinary,  
	  const char * data,  
	  int length  
	);

typedef
void														
(*OnError_t)(
	  const char* connectionID,  
	  const char * message,  
	  int length  
	);

typedef
void														
(*OnClose_t)(
	  const char* connectionID,  
	  int isClosedByClient,  
	  int code,  
	  const char* reason,  
	  int length  
	 );
 
 
 
 
 





# 7 "globals.h" 2

# 1 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrw_custom_body.h" 1
 





# 8 "globals.h" 2


 
 


# 3 "c:\\adminplanit\\vugen scripts\\bcfhtmlmobilechrome001\\\\combined_BCFHTMLMobileChrome001.c" 2

# 1 "vuser_init.c" 1
vuser_init()
{
	return 0;
}
# 4 "c:\\adminplanit\\vugen scripts\\bcfhtmlmobilechrome001\\\\combined_BCFHTMLMobileChrome001.c" 2

# 1 "Action.c" 1
Action()
{

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

	
	web_cleanup_cookies();
	web_cache_cleanup();
	
	lr_start_transaction("Load BCF");

	web_add_cookie("UserLocationCountry=1; DOMAIN=www.bcf.com.au");
	web_add_cookie("StoreLocation=id=328&name=BCF Auburn&state=NSW&link=/Stores/BCF-Auburn/328&regional=false&version=1.1; DOMAIN=www.bcf.com.au");
	web_add_cookie("bn_u=6926840889199666601; DOMAIN=www.bcf.com.au");
	web_add_cookie("__utma=169374002.1724835083.1501714995.1501714995.1501724266.2; DOMAIN=www.bcf.com.au");
	web_add_cookie("__utmz=169374002.1501714995.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); DOMAIN=www.bcf.com.au");
	web_add_cookie("_vwo_uuid_v2=4C624E2E1F547F5A5765D166AC9EEB67|d1ee0b04db032ad85a417da05b61068a; DOMAIN=www.bcf.com.au");
	web_add_cookie("__ar_v4=POB5OBOK7ZAQLPZH64IM7W%3A20170801%3A8%7CHQ6BLEGB2BA6TKZMMKXFGZ%3A20170801%3A8%7C67Z3BVRYOFFZNC5W3YD4VA%3A20170801%3A8; DOMAIN=www.bcf.com.au");
	web_add_cookie("ASP.NET_SessionId=2z0app4dp2rbaexihyuyulow; DOMAIN=www.bcf.com.au");
	web_add_cookie("TS0132ffa2=01fb45418361b0aa0016b0564abb8bfdf08b8dff5acd487fa2e412dce7f444fa471df0085ec221ef7cd67c4d4db591dac431d3463f; DOMAIN=www.bcf.com.au");
	web_add_cookie("MR=0; DOMAIN=bat.bing.com");
	web_add_cookie("MUIDB=2622D1A6CE9A60481607DB74CA9A634F; DOMAIN=bat.bing.com");
	web_add_cookie("MUID=2622D1A6CE9A60481607DB74CA9A634F; DOMAIN=bat.bing.com");


	web_reg_find("Text=Boating, Camping and Fishing Store Online - BCF Australia", 
	"LAST");
	
	web_url("www.bcf.com.au", 
		"URL=http://www.bcf.com.au/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=http://dev.visualwebsiteoptimizer.com/j.php?a=131227&u=http%3A%2F%2Fwww.bcf.com.au%2F&r=0.9822991506283631", "ENDITEM", 
		"Url=/authentication/get", "ENDITEM", 
		"Url=http://dev.visualwebsiteoptimizer.com/v.gif?a=131227&d=bcf.com.au&u=4C624E2E1F547F5A5765D166AC9EEB67&h=d1ee0b04db032ad85a417da05b61068a&t=false&r=0.7490297821103895", "ENDITEM", 
		"Url=/Stores/GetNearest", "ENDITEM", 
		"Url=http://www.googletagmanager.com/gtm.js?id=GTM-JHWT", "ENDITEM", 
		"Url=http://a.adroll.com/j/roundtrip.js", "ENDITEM", 
		"Url=https://connect.facebook.net/en_US/fbevents.js", "ENDITEM", 
		"Url=http://bat.bing.com/bat.js", "ENDITEM", 
		"Url=http://super-bcf.baynote.net/baynote/tags3/baynoteObserver/listener2?customerId=super&code=bcf&msgId=0&fmt=1&len=214&msg=%7B%22a%22%3A%22v%22%2C%22c%22%3A%22d%26g%26s%22%2C%22d%22%3A%22http%3A%2F%2Fwww.bcf.com.au%2F%22%2C%22r%22%3A%22%22%2C%22t%22%3A1501735154524%2C%22u%22%3A%226926840889199666601%22%2C%22at%22%3A%7B%22StoreLocation%22%3A%22id%3D328%26name%3DBCF%20Auburn%26state%3DNSW%26link%3D%2FStores%2FBCF-Auburn%2F328%26regional%3Dfalse%26version%3D1.1%22%7D%7D", "ENDITEM", 
		"Url=http://super-bcf.baynote.net/baynote/tags3/baynoteObserver/listener2?customerId=super&code=bcf&msgId=1&fmt=1&len=222&msg=%7B%22a%22%3A%22l%22%2C%22c%22%3A%22d%26g%26s%22%2C%22d%22%3A%22http%3A%2F%2Fwww.bcf.com.au%2F%22%2C%22r%22%3A%22%22%2C%22t%22%3A1501735218732%2C%22u%22%3A%226926840889199666601%22%2C%22at%22%3A%7B%22StoreLocation%22%3A%22id%3D328%26name%3DBCF%20Auburn%26state%3DNSW%26link%3D%2FStores%2FBCF-Auburn%2F328%26regional%3Dfalse%26version%3D1.1%22%7D%2C%22du%22%3A30%7D", "ENDITEM", 
		"Url=https://connect.facebook.net/signals/config/923391787702806?v=2.7.19", "ENDITEM", 
		"Url=http://super-bcf.baynote.net/baynote/tags3/baynoteObserver/listener2?customerId=super&code=bcf&msgId=2&fmt=1&len=385&msg="
		"%7B%22a%22%3A%22c%22%2C%22c%22%3A%22d%26g%26s%22%2C%22d%22%3A%22http%3A%2F%2Fwww.bcf.com.au%2F%22%2C%22r%22%3A%22%22%2C%22t%22%3A1501735452584%2C%22u%22%3A%226926840889199666601%22%2C%22at%22%3A%7B%22StoreLocation%22%3A%22id%3D328%26name%3DBCF%20Auburn%26state%3DNSW%26link%3D%2FStores%2FBCF-Auburn%2F328%26regional%3Dfalse%26version%3D1.1%22%7D%2C%22trackingData%22%3Anull%2C%22dd%22%3A%22http%3A%2F%2Fwww.bcf.com.au%2Fstore%2Fmanagers-specials%2F5041506%22%2C%22de%22%3A%7B%22ti%22%3A%22Boating%2C%20"
		"Camping%20and%20Fishing%20Store%20Online%20-%20BCF%20Australia%22%2C%22nw%22%3A133%2C%22nl%22%3A920%7D%7D", "ENDITEM", 
		"LAST");

	web_add_cookie("__utmt=1; DOMAIN=www.bcf.com.au");
	web_add_cookie("__utma=169374002.1724835083.1501714995.1501724266.1501735149.3; DOMAIN=www.bcf.com.au");
	web_add_cookie("__utmb=169374002.1.10.1501735149; DOMAIN=www.bcf.com.au");
	web_add_cookie("__utmc=169374002; DOMAIN=www.bcf.com.au");

	web_custom_request("GetCart", 
		"URL=http://www.bcf.com.au/ShoppingCart/GetCart", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://www.bcf.com.au/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"plu\":null,\"quantity\":null,\"sourceID\":null}", 
		"LAST");

	 

	web_url("0", 
		"URL=http://bat.bing.com/action/0?ti=5256926&Ver=2&mid=ae25949d-a52a-245d-044c-4426c9404a6c&evt=pageLoad&sid=4373206d-1&lt=24731&pi=0&lg=en-GB&sw=400&sh=738&sc=24&tl=Boating,%20Camping%20and%20Fishing%20Store%20Online%20-%20BCF%20Australia&kw=BCF,%20Boating,%20Camping%20and%20Fishing%20Store%20Online%20-%20BCF%20Australia&p=http%3A%2F%2Fwww.bcf.com.au%2F&r=&rn=767872", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://www.bcf.com.au/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"LAST");

	web_add_cookie("refresh=NoUpdate; DOMAIN=connexity.net");
	web_add_cookie("sync=133_134_132_61_45_65_54_23_48_55_17_73_22_74; DOMAIN=connexity.net");
	web_add_cookie("COu=e9130e0e60a7f797-06221138786d19a9-211dc3652322137f; DOMAIN=connexity.net");


	web_url("cse", 
		"URL=http://connexity.net/c/cse?a=S&A=232&D=576d&V=10&R=400x738c24&T=6e&I0k=prodid&I0v=%23%23INSERT_PRODUCT_ID%23%23&J=http%3A%2F%2Fwww.bcf.com.au%2F&b=2193", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.bcf.com.au/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"LAST");

	lr_end_transaction("Load BCF",2);

	
	lr_think_time(4);

	
	lr_start_transaction("Select Item");

	web_url("cse_2", 
		"URL=http://connexity.net/c/cse?a=P&A=232&C=0&D=576d&N=0-1a5b4c1526340eb7&R=400x738c24&T=6e&U=e9130e0e60a7f797-06221138786d19a9-211dc3652322137f&J=http%253a%252f%252fwww.bcf.com.au%252f&V=10&I0k=prodid&I0v=%23%23INSERT_PRODUCT_ID%23%23&Q=v2.0.1,c:y,h5L:y,TS:(run:126392ms),(Burl-R:126401ms),(Burl-P:126403ms)", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://connexity.net/c/cse?a=S&A=232&D=576d&V=10&R=400x738c24&T=6e&I0k=prodid&I0v=%23%23INSERT_PRODUCT_ID%23%23&J=http%3A%2F%2Fwww.bcf.com.au%2F&b=2193", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=cse?a=R&A=232&C=0&D=576d&N=0-1a5b4c1526340eb7&R=400x738c24&T=6e&U=e9130e0e60a7f797-06221138786d19a9-211dc3652322137f&J=http%253a%252f%252fwww.bcf.com.au%252f&V=10&I0k=prodid&I0v=%23%23INSERT_PRODUCT_ID%23%23&Q=v2.0.1,c:y,h5L:y,TS:(run:126392ms),(Burl-R:126401ms)", "Referer=http://connexity.net/c/cse?a=S&A=232&D=576d&V=10&R=400x738c24&T=6e&I0k=prodid&I0v=%23%23INSERT_PRODUCT_ID%23%23&J=http%3A%2F%2Fwww.bcf.com.au%2F&b=2193", "ENDITEM", 
		"Url=http://10.9.20.77:8008/ssdp/device-desc.xml", "Referer=", "ENDITEM", 
		"LAST");

	web_add_cookie("id=22303df8da440095||t=1501714999|et=730|cs=002213fd48a473df31c4a81650; DOMAIN=6771107.fls.doubleclick.net");
	web_add_cookie("IDE=AHWqTUld4EnMnG67CI5GENHedq55o_LlkoDPquBRBNkPjBdhw6NgykUMaA; DOMAIN=6771107.fls.doubleclick.net");


	web_url("activityi;src=6771107;type=invmedia;cat=bchhyctd;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=6972012504137.164",
		"URL=https://6771107.fls.doubleclick.net/activityi;src=6771107;type=invmedia;cat=bchhyctd;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=6972012504137.164?", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://connexity.net/c/cse?a=P&A=232&C=0&D=576d&N=0-1a5b4c1526340eb7&R=400x738c24&T=6e&U=e9130e0e60a7f797-06221138786d19a9-211dc3652322137f&J=http%253a%252f%252fwww.bcf.com.au%252f&V=10&I0k=prodid&I0v=%23%23INSERT_PRODUCT_ID%23%23&Q=v2.0.1,c:y,h5L:y,TS:(run:126392ms),(Burl-R:126401ms),(Burl-P:126403ms)", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"LAST");

	web_add_cookie("NID=107=l5kfHqCDw77VFRSGIaMxndMiaam_no4lSJfAtG4ObdnRFy2IbjZgOJVY9NlgZrpYfiWZ2rfF0CXvIwtl4tijQ3fXUfe0LUq5S5wBtv6lC4JDWtdmg3T9QeGo5q1lMvtB; DOMAIN=safebrowsing-cache.google.com");

	web_custom_request("downloads", 
		"URL=https://safebrowsing.google.com/safebrowsing/downloads?client=googlechrome&appver=60.0.3112.78&pver=3.0&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&ext=0", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/vnd.google.safebrowsing-update", 
		"Referer=", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body=goog-malware-shavar;a:252895-271200:s:248091-248437,248439-248463,248465-248532,248534-248537,248539-248587,248589-248592,248594-248660,248662-248693,248695-248753,248755-248810,248812-248832,248835-248931,248933-248955,248957-248959,248961-248967,248969-248971,248973,248975-248984,248986,248988-249034,249036,249038-249040,249042,249044,249046-249048,249050,249052,249054-249059,249061-249105,249107-249125,249127-249231,249233-249242,249244-249313,249315-249385,249387-249388,249390-249446,"
		"249448-249452,249454-249465,249467,249469-249473,249476-249524,249526-249538,249540,249542-249544,249546-249657,249659-249660,249662-249671,249673-249725,249727-249736,249738-249856,249858-249875,249878-249926,249928-249938,249940-249958,249960-249961,249963-249991,249993-249994,249996-250037,250039-250054,250056-250057,250059-250218,250220-250284,250286-250331,250333-250341,250343-250351,250353-250405,250407-250413,250415-250419,250422-250433,250435-250467,250469-250475,250477-250478,"
		"250481-250493,250495-250512,250514-250516,250518-250622,250624-250629,250631-250637,250639-250655,250657-250715,250717-250718,250720-250728,250730-250747,250749-250796,250799-250800,250802-250811,250813,250815-250818,250820-250880,250882,250884-250885,250887-250895,250897-250905,250908-250909,250912-250941,250943-250950,250952-250958,250961-250965,250969-250970,250972-250975,250977,250979-250997,250999-251018,251021-251039,251041-251046,251049-251052,251055-251057,251060-251070,251073-251077,"
		"251079-251082,251084-251098,251100-251130,251132-251136,251138-251144,251146-251154,251157-251204,251206-251210,251212-251218,251220-251232,251234-251238,251240-251285,251287-251298,251300-251306,251308-251318,251320-251450,251452-251483,251486-251517,251519-251537,251539-251543,251546-251547,251549-251627,251629,251633-251644,251646-251790,251792-251794,251796-251955,251957-251960,251962-251965,251967-252031,252033-252084,252086-252104,252106-252121,252123,252125-252155,252157-252177,"
		"252179-252195,252200-252201,252203-252208,252210,252212-252218,252220-252230,252232-252234,252236-252244,252246,252248-252263,252265,252267-252274,252276,252278,252280-252358,252360-252361,252363-252374,252376-252382,252384-252703,252705-253174,253176-253509,253511-262839,262841-263875,263877-264204,264206-267149\ngoog-phish-shavar;a:472768-484921:s:308830-308865,308867,308869-308871,308873-308884,308886-308899,308901-308907,308909-308924,308927-308944,308946-308958,308960-308974,308976-308993,"
		"308995,308997-309016,309018-309030,309032-309044,309046-309078,309081-309095,309097-309121,309123-309154,309156-309191,309193,309195-309202,309204-309216,309218-309250,309252-309337,309339-309349,309351-309366,309368-309390,309392-309428,309430-309451,309453-309463,309465,309467-309473,309475-309480,309482-309483,309485-309503,309505-309511,309513,309515-309516,309518-309523,309525-309583,309585-309593,309595-309604,309606,309608-309618,309620-309805,309807-309817,309819-309833,309835-309860,"
		"309862-309900,309902-309906,309908-309924,309926-309927,309929,309931-309940,309942-309946,309949-309964,309966-309968,309970-310037,310039-310055,310057-310063,310065-310069,310072-310077,310079-310094,310096-310106,310108-310117,310119-310124,310126-310132,310134-310142,310144-310150,310152-310180,310182-310220,310222-310227,310229-310235,310237-310247,310249-310257,310259-310288,310290-310307,310309-310339,310341-310367,310369-310377,310379-310403,310405-310419,310421-310444,310446-310447,"
		"310449-310505,310507-310525,310527-310529,310531-310567,310569-310579,310581-310585,310587-310597,310599,310601-310603,310605-310636,310639-310653,310655-310669,310671-310703,310705-310725,310727-310740,310742-310749,310751-310769,310771-310775,310777-310792,310794-310826,310828-310847,310849-310860,310862-310877,310880-310882,310884-310893,310895-310905,310907-310974,310976-311014,311016-311031,311033-311039,311041-311059,311061-311098,311100-311109,311111-311119,311121-311124,311126-311141,"
		"311143-311172,311174,311176-311186,311188-311189,311191-311198,311200-311269,311271-311290,311292-311296,311298-311327,311329-311331,311333-311367,311370-311391,311393-311410,311412-311420,311422-311447,311449-311452,311454-311457,311459-311535,311537-311545,311547-311574,311576-311577,311579-311587,311589-311607,311609-311620,311622-311654,311656-311676,311678-311726,311728-311783,311785-311793,311795-311822,311824-311836,311838-311859,311861-311868,311870-311874,311876-311878,311880,"
		"311882-311884,311886-311889,311891-311902,311905-311909,311911-311920,311922,311924-311931,311933,311935-311956,311958-311960,311962-311966,311968-311971,311973-311977,311979,311981-311991,311993,311995,311997,311999,312001,312003-312010,312012-312025,312027-312030,312032,312034,312036-312040,312043-312055,312057-312095,312097,312099-312116,312118-312128,312130-312156,312158-312161,312163-312165,312167-312172,312174-312186,312188,312190-312206,312208-312238,312240,312242-312286,312288-312324,"
		"312326-312338,312340-312343,312345-312356,312358-312395,312397-312401,312403-312430,312432-312435,312437-312455,312457-312463,312465-312476,312478-312506,312508-312520,312522-312525,312527-312541,312543-312577,312579-312581,312583-312593,312595-312622,312624-312709,312711-312733,312735-312798,312800-312872,312874-312879,312881-312888,312890-312927,312929-312950,312952-312994,312996-313029,313031-313064,313066-313159,313161-313177,313179-313182,313184-313186,313188-313274,313276-313289,"
		"313291-313328,313330-313336,313338-313355,313357-313378,313380-313437,313439-313456,313458-313504,313506-313553,313555-313558,313560-313596,313598-313636,313638-313647,313649-313674,313676-313680,313682-313688,313690-313735,313737-313742,313744-313756,313758-313760,313762-313811,313813-313836,313838-313839,313841-313848,313850-313856,313858-313880,313882-313889,313891-313899,313901,313903-313906,313908-313923,313925-313937,313939-313943,313945-313954,313956,313958-313983,313985-313987,"
		"313989-313991,313993-314001,314004-314013,314015-314032,314034,314036-314048,314050-314058,314060-314068,314070,314072-314073,314075-314076,314078-314081,314083-314085,314087-314094,314096-314097,314099-314102,314104-314134,314136-314137,314139-314144,314146-314162,314164-314200,314202-314208,314210-314229,314231-314240,314242-314245,314247-314253,314255-314296,314298-314315,314317-314330,314332-314335,314337-314339,314341-314344,314346-314370,314372-314384,314386-314393,314395-314424,"
		"314426-314446,314448-314458,314460-314477,314479-314501,314503-314534,314536-314544,314546-314551,314553-314554,314556-314568,314570-314589,314591-314593,314595-314606,314608-314618,314620-314633,314635-314640,314642-314643,314645-314655,314657,314660-314662,314664-314666,314668-314692,314694-314706,314709-314727,314730-314742,314744-314747,314749-314756,314758-314764,314766,314768-314780,314783-314788,314790-314801,314803-314819,314821-314823,314825-314828,314830-314843,314846-314858,"
		"314860-314864,314867-314873,314875-314887,314889-314894,314896-314971,314973-314987,314989-315016,315018-315021,315023-315025,315027-315033,315035,315037-315039,315041-315045,315047-315056,315058-315073,315075-315078,315080-315081,315083-315085,315087-315111,315113-315128,315131-315149,315152,315154-315174,315176,315178-315179,315181-315221,315223-315237,315240-315245,315247-315251,315253-315272,315274-315276,315278,315280-315285,315287-315289,315291-315307,315309-315314,315316-315319,"
		"315321-315324,315326-315340,315342,315344-315364,315366-315372,315374-315377,315380-315384,315386-315397,315399-315403,315405-315416,315418,315420-315431,315433-315440,315443,315445-315447,315449-315451,315453-315468,315470-315484,315486-315495,315497-315522,315524-315531,315533-315541,315543-315545,315547-315552,315554-315563,315565-315576,315578-315584,315586-315592,315594-315610,315612,315614,315616-315623,315625-315636,315638,315640-315642,315644-315649,315651-315655,315657-315668,315670,"
		"315672-315676,315678-315681,315683-315685,315687-315689,315691-315694,315696-315710,315712-315729,315731-315733,315735-315742,315744-315746,315748-315753,315755-315759,315761-315762,315764-315778,315780,315782-315788,315790-315800,315802-315811,315813-315814,315816-315819,315821-315836,315838-315858,315860-315894,315896-315932,315934-315937,315939-315942,315944-315965,315967-315973,315975-315989,315991-316010,316012-316020,316022-316027,316029-316059,316061-316075,316077-316082,316084-316085,"
		"316087,316089-316484,316486-316502,316504-316916,316918-316990,316992-317395,317397-317401,317404,317406-328349\ngoog-badbinurl-shavar;a:132025-133589:s:135344-136188,136190-137092\ngoog-csdwhite-sha256;a:254-384:s:126-230\ngoog-downloadwhite-digest256;a:5-84:s:2-7,10-59\ngoog-badcrxids-digestvar;a:2-2086:s:1,3-190\ngoog-badip-digest256;a:2844\ngoog-unwanted-shavar;a:76385-99260:s:71811,71813-71817,71820-71821,71823-71826,71828,71830,71833,71837,71840,71842-71846,71849-71853,71856-71857,71859,"
		"71861-71864,71866,71870,71874-71877,71879-71880,71882-71883,71889,71893-71895,71897-71902,71906,71908,71910-71911,71914-71915,71918-71924,71929-71930,71932,71939,71942,71944,71949,71951-71953,71956-71957,71959,71963,71967-71970,71972-71973,71975-71978,71981-71986,71988,71991,71993,71995,71999-72002,72004-72006,72009-72012,72014,72017,72019-72021,72023-72029,72032,72035,72049,72051,72054,72067,72072-72075,72078-72079,72081,72084-72086,72095,72097,72102-72103,72105,72108-72112,72114,72118-72120,"
		"72122-72124,72126-72127,72129-72131,72133,72136,72143,72152,72156,72158-72160,72163,72168-72169,72182,72189,72191,72198,72201,72203,72206-72207,72213,72218,72225,72227,72229,72231-72232,72238-72239,72241,72243-72245,72247,72249,72251,72254-72257,72262,72265-72276,72279,72281-72282,72285-72286,72288-72289,72299,72306,72308,72310,72314-72315,72318,72320,72322-72326,72328-72331,72333-72335,72340,72344-72345,72347-72352,72355-72358,72360,72362,72367,72371-72372,72374-72377,72379,72382-72384,72387,"
		"72389-72394,72401-72402,72404-72405,72407,72409,72411-72414,72416-72418,72420-72421,72424,72426-72430,72432,72434,72436-72437,72439-72442,72446,72448-72450,72452-72454,72461-72464,72466-72468,72470,72472-72473,72478,72480,72486-72491,72498,72500,72504-72506,72508-72510,72512,72514,72516,72522-72524,72526-72527,72530-72533,72536-72537,72539-72543,72545-72548,72550,72552,72554-72555,72557,72559-72562,72564-72570,72572,72575,72578-72579,72582-72584,72586-72587,72590-72598,72601,72603-72604,72607,"
		"72610,72612-72616,72619-72621,72623-72631,72635-72639,72642-72649,72651-72660,72663-72667,72670-72671,72674-72676,72678-72680,72683,72686-72688,72690-72695,72697-72700,72702-72704,72706-72707,72709-72716,72719-72725,72727,72729-72734,72738-72740,72743,72745-72747,72749-72753,72755,72757-72772,72774-72776,72778-72779,72782,72784,72787-72788,72790-72791,72793-72797,72800,72804-72808,72812-72814,72816-72817,72821-72822,72825-72827,72831-72835,72837-72844,72846-72853,72856-72859,72861-72862,"
		"72864-72868,72870,72872-72874,72881,72883,72885-72896,72898-72901,72903,72905,72907-72908,72911-72916,72918,72921-72936,72938-72939,72941-72942,72945-72947,72949-72957,72962-72963,72965-72966,72968-72973,72975-72978,72980,72982-72984,72987-72991,72994-72995,72999-73006,73008-73015,73017-73019,73022,73024-73027,73029-73030,73032-73047,73049-73060,73063-73064,73067,73069,73071-73079,73081-73082,73084-73088,73092-73096,73098,73100-73102,73104-73106,73108-73110,73112,73114,73117,73119-73120,73122,"
		"73133-73134,73138,73142-73143,73146-73147,73149,73151,73155-73156,73159,73168,73179-73180,73188-73189,73194,73197-73198,73204,73206,73208-73215,73217-73220,73222-73226,73228-73235,73237-73238,73240-73245,73247,73251,73253,73255,73259,73261,73263-73274,73276-73284,73286,73288,73290-73292,73295-73297,73299,73302-73303,73305-73311,73313-73314,73316,73318-73325,73327-73342,73344-73365,73367-73369,73372-73379,73381-73384,73386-73391,73393-73397,73400,73402-73409,73411-73414,73416-73424,73426-73435,"
		"73437-73438,73440-73452,73454-73455,73457-73464,73466-73467,73471-73472,73476,73478-73489,73491-73497,73499-73504,73506-73509,73511-73518,73520-73525,73527-73530,73532-73541,73543-73551,73553-73555,73557-73565,73567-73574,73579-73594,73596-73607,73610-73616,73618-73631,73633-73642,73644-73651,73653-73663,73665-73666,73668-73670,73675,73677-73680,73683-73711,73713-73714,73716-73717,73719-73720,73722-73725,73727-73740,73742-73766,73768-73771,73773-73785,73787-73792,73795-73796,73798,73800-73807,"
		"73809-73822,73824,73826,73828-73844,73846-73851,73853-73855,73857-73860,73862-73865,73867-73878,73880-73887,73890-73892,73895-73899,73901-73902,73904,73909,73911-73916,73921-73933,73935-73942,73944-73950,73952-73954,73956-73962,73964-73965,73967-73969,73971-73974,73976-73977,73979-73982,73985-73997,73999-74005,74007-74008,74010-74015,74017-74022,74024-74027,74029-74042,74044-74050,74052-74067,74069-74070,74073,74075-74079,74082-74090,74093-74099,74101-74109,74113-74114,74116-74120,74122,74124,"
		"74128-74139,74141-74144,74146-74155,74158-74159,74161-74164,74166-74175,74177-74186,74188-74213,74217-74219,74221-74225,74227-74236,74238-74257,74259-74267,74269-74278,74280-74292,74294-74303,74305-74308,74311-74332,74334-74336,74339-74340,74353-74373,74375-74382,74384-74385,74387-74388,74390-74405,74408-74424,74426-74431,74433-74437,74439-74440,74443-74465,74467,74469,74471-74476,74478-74480,74483-74484,74487-74489,74491-74498,74500-74502,74504-74514,74516-74521,74523,74525-74526,74528-74533,"
		"74535-74545,74547-74551,74553-74563,74567-74568,74570,74573-74575,74577-74585,74587-74592,74594-74628,74630-74633,74635,74637-74643,74645-74658,74660-74666,74668-74671,74675-74692,74694-74697,74699,74701-74711,74713,74716-74736,74738,74740-74741,74743-74750,74752-74760,74762-74765,74767-74772,74774-74777,74780,74783,74785,74788-74792,74794-74798,74800-74803,74806,74809,74811-74812,74814,74818-74824,74826-74829,74831-74832,74834,74836-74841,74843-74847,74849-74853,74855-74869,74872-74886,"
		"74891-74892,74894,74896,74898-74899,74904,74908-74917,74921-74924,74926-74928,74930-74935,74941,74943-74947,74949-74954,74956,74958-74963,74966-74972,74974-74976,74979-74981,74983-74993,74995,74997-75001,75003-75015,75017-75020,75022-75026,75028,75030-75048,75051-75053,75055-75061,75063,75065-75074,75077-75079,75081-75092,75094-75095,75097,75099-75102,75105-75106,75109-75113,75115-75120,75122,75124-75125,75127-75161,75165,75167-75177,75179-75180,75182,75184-75188,75190-75191,75193,75195,75197,"
		"75199-75200,75202-75203,75205-75210,75214-75227,75229,75232,75234-75240,75242-75255,75257-75262,75266,75268-75273,75276-75278,75281-75292,75294-75363,75365-75372,75374-75380,75382,75384-75389,75391-75392,75394-75400,75403-75415,75417-75418,75420-75430,75432-75449,75451-75467,75469-75490,75492-75498,75500-75503,75505-75522,75525-75534,75536-75547,75549,75551-75562,75566-75582,75584-75587,75589-75596,75598-75606,75608-75609,75611-75646,75649,75652,75656-75674,75676-75682,75684-75721,75723,"
		"75725-75730,75732-75763,75765,75769-75776,75779,75781-75796,75798-75830,75832,75834-75851,75853-75856,75859-75870,75872-75875,75877-75884,75887-75888,75890-75961,75963-75969,75971-75973,75975-75999,76001-76002,76006-76018,76021-76026,76028,76030-76036,76038-76045,76047-76053,76055-76056,76058-76071,76073-76083,76085-76086,76088,76090-76092,76094-76097,76100-76107,76109-76142,76144-76163,76169-76176,76178-76181,76184-76188,76191,76193-76200,76202-76207,76209-76214,76217,76219-76224,76226-76243,"
		"76245-76247,76249-76257,76261-76289,76291-76293,76295-76297,76299-76308,76310-76313,76316-76324,76326-76370,76372,76374-76390,76392-76406,76408-76413,76417-76420,76423-76437,76439-76450,76452-76467,76470-76494,76497-76509,76511-76577,76580-76589,76592-76610,76613-76631,76634-76657,76659-76661,76663,76666-76672,76674,76676-76711,76713-76745,76747-76755,76757-76764,76766-76781,76783-76795,76798-76820,76822-76837,76839-76866,76868-76898,76901-76942,76945-76953,76956-76988,76990-77002,77004-77010,"
		"77012-77016,77018-77026,77028-77036,77038-77047,77050-77088,77090-77125,77127-77309,77311-77324,77326-77344,77346-77376,77378-77383,77386-77454,77456-77460,77462-77475,77477-77493,77497-77546,77548-77587,77589-77596,77598-77612,77614-77623,77625-77629,77631-77656,77658-77727,77729-77762,77764,77766-77773,77775-77830,77832-77836,77838-77843,77845-77865,77867-77876,77878-77883,77885-77899,77901-77949,77951-77959,77961-77979,77981-77983,77985-77987,77989-77996,77998-78047,78049-78068,78070-78100,"
		"78102-78111,78113-78119,78121-78128,78130-78132,78134-78186,78188-78238,78240-78248,78250-78265,78267-78300,78302-78320,78322-78339,78341-78373,78375-78417,78419-78441,78444-78458,78460-78480,78482-78496,78498-78502,78504-78535,78537-78544,78548-78634,78636-78677,78679-78695,78697-78702,78704-78718,78720-78744,78746-78783,78785-78786,78789-78794,78796-78827,78829,78831-78911,78913-78942,78945-78959,78961-79000,79002-79013,79015-79076,79078-79083,79085-79088,79091-79094,79096-79123,79125-79174,"
		"79176-79201,79203-79218,79220-79222,79224-79225,79227-79245,79247-79250,79252-79258,79260-79268,79270-79274,79276-79308,79311-79312,79314-79321,79323-79329,79331-79336,79338-79356,79358-79368,79370-79394,79396-79416,79418-79462,79464-79474,79476-79516,79519-79547,79549-79561,79563-79600,79603-79616,79618-79660,79662-79683,79685-79688,79690-79733,79735-79742,79744-79757,79759-79793,79796-79845,79847-79863,79865-79876,79878-79965,79967-79992,79994-80004,80006-80014,80016-80056,80058-80061,"
		"80063-80077,80079-80082,80084-80088,80090-80101,80103-80105,80107-80110,80112-80114,80116-80118,80120-80142,80144-80146,80148-80155,80157-80188,80190-80211,80213-80224,80226-80257,80259-80269,80271-80289,80291-80301,80303-80304,80306-80328,80330-80333,80335-80342,80344-80362,80365-80366,80368-80398,80400-80441,80443-80447,80449-80513,80515-80529,80531-80584,80586-80633,80635-80640,80642-80645,80647-80648,80650-80656,80658-80718,80720-80728,80730-80863,80865-80919,80921-80926,80928-80941,"
		"80943-80944,80946-80960,80963-80966,80968-80975,80977-80980,80982-80988,80991-80992,80994-81002,81005-81017,81020-81037,81039-81098,81100-81134,81136-81256,81258-81351,81353-81361,81363-81367,81370-81434,81436-81542,81544-81566,81568-81656,81658-81693,81695-81753,81756-81763,81766,81768-81771,81773-81804,81806-82001,82003-82028,82030-82126,82128,82130-82234,82236-82352,82355-82379,82381-82390,82392-82412,82414-82437,82439-82456,82458-82560,82562-82755,82757,82759-82776,82778-82814,82816-82842,"
		"82844-82947,82949-83087,83089-83090,83092-83179,83181,83184-83299,83301-83369,83371-83446,83448-83485,83487-83542,83544-83674,83677-83745,83747-83796,83798-84009,84011-84015,84017-84205,84207-84381,84383-84722,84724-84780,84782-84829,84831-84905,84907-84939,84941-85022,85024-85193,85195-85227,85229-85231,85233-85247,85249-85259,85261-85595,85597-85888,85890-85939,85941-85950,85952-86170,86172-86333,86335-86499,86501-86640,86642-86741,86743-87028,87030-87083,87085-87092,87094-87147,87149,"
		"87151-87154,87156-87225,87227-87235,87237-87294,87296-87385,87387-87443,87445-87651,87653-87715,87717-88123,88125-88419,88421-88484,88486,88489-88661,88663-88697,88699-88868,88870-88948,88950-89119,89121-89175,89177-89187,89189-89239,89241-89265,89267-89274,89276-89307,89309-89365,89367-89419,89421-89511,89513-89653,89655-89870,89872-90226,90228-90237,90239-90518,90520-90742,90745-90819,90821-91026,91028-91071,91073-91240,91242-91312,91314-91354,91356-91515,91517,91519-91680,91682-91711,"
		"91713-91944,91946-91984,91986-92049,92051-94637\ngoog-whitemodule-digest256;a:1-93\ngoog-badresource-shavar;a:1-11\n", 
		"EXTRARES", 
		"Url=https://safebrowsing-cache.google.com/safebrowsing/rd/ChVnb29nLWJhZGJpbnVybC1zaGF2YXI4AUACSgwIARCFrwgYha8IIAFKDAgAENaTCBjWkwggAQ", "Referer=", "ENDITEM", 
		"LAST");


	web_custom_request("update2", 
		"URL=https://update.googleapis.com/service/update2?cup2key=7:3536315096&cup2hreq=7430a88693aadee92a43168bb179b8f37acfcde57900ca7ce2bcff0d3b269c97", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=application/xml", 
		"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?><request protocol=\"3.1\" dedup=\"cr\" acceptformat=\"crx2,crx3\" version=\"chrome-60.0.3112.78\" prodversion=\"60.0.3112.78\" requestid=\"{a0362de8-60b0-4d11-b6dd-b15ba180b7fa}\" lang=\"en-GB\" updaterchannel=\"\" prodchannel=\"\" os=\"win\" arch=\"x86\" nacl_arch=\"x86-64\" wow64=\"1\" domainjoined=\"1\"><hw physmemory=\"8\"/><os platform=\"Windows\" arch=\"x86_64\" version=\"10.0.15063.483\"/><updater autoupdatecheckenabled=\"1\" lastchecked=\"0\" "
		"laststarted=\"0\" name=\"Omaha\" updatepolicy=\"0\" version=\"1.3.33.5\"/><app appid=\"mimojjlkmoijpicakmndhoigimigcmbb\" version=\"26.0.0.137\" brand=\"GGRV\" cohort=\"1:d0j:\" cohortname=\"Chrome [M50... M99]\"><updatecheck/><ping rd=\"3866\" ping_freshness=\"{802584a4-fcb2-405f-bd9c-295780214a65}\"/><packages><package fp=\"1.4bcc0b17ab91b8d88db4f8a04b154d967d018a2e33954b06abf0ffe7ed3b7b33\"/></packages></app><app appid=\"oimompecagnajdejgnnjijobebaeigek\" version=\"1.4.8.1000\" brand=\"GGRV\">"
		"<updatecheck/><ping rd=\"3866\" ping_freshness=\"{5e2482d5-d59d-4dc0-a4d5-2ab78202e137}\"/></app><app appid=\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\" version=\"7.54\" brand=\"GGRV\" cohort=\"1:bm1:\" cohortname=\"M54AndAbove\"><updatecheck/><ping rd=\"3866\" ping_freshness=\"{06707018-537e-412e-98c0-ef9855eee10d}\"/><packages><package fp=\"1.e5ac6a4f2e3fd1eef8a61bf912c880dcbe57adcee6415d892c84e7e85ea476dc\"/></packages></app><app appid=\"oafdbfcohdcjandcenmccfopbeklnicp\" version=\"7\" brand=\"GGRV\">"
		"<updatecheck/><ping rd=\"3866\" ping_freshness=\"{6c7dbd83-3e63-4be3-a238-690c8212529e}\"/><packages><package fp=\"1.1d358758a4bc326dadea05039ccbe0f26f6cc478b796f6a967f74c8fadf73d8a\"/></packages></app><app appid=\"ojjgnpkioondelmggbekfhllhdaimnho\" version=\"466\" brand=\"GGRV\" cohort=\"1:0:\" cohortname=\"Auto\"><updatecheck/><ping rd=\"3866\" ping_freshness=\"{737e5e85-221c-428b-914b-e23f472df03d}\"/><packages><package fp=\"1.6ad8846b0972447f91b52293440232e593b46500fd3ac07244a9a2d4b920b0a5\"/>"
		"</packages></app><app appid=\"llkgjffcdpffmhiakmfcdcblohccpfmo\" version=\"0.0.0.0\" brand=\"GGRV\"><updatecheck/><ping rd=\"3866\" ping_freshness=\"{a9d25495-ec34-4589-a41e-ce89d1487061}\"/></app><app appid=\"khaoiebndkojlmppeemjhbpbandiljpe\" version=\"11\" brand=\"GGRV\" cohort=\"1:cux:\" cohortname=\"Auto\"><updatecheck/><ping rd=\"3866\" ping_freshness=\"{012eb7d1-5547-49ba-95dd-e15896cd08e7}\"/><packages><package fp=\"1.a67bbe7188e0335f00c488209bd4dfe39cb26a916c379c4416479d83e63761ef\"/></"
		"packages></app><app appid=\"giekcmmlnklenlaomppkphknjmnnpneh\" version=\"3\" brand=\"GGRV\" cohort=\"1:j5l:\" cohortname=\"Auto\"><updatecheck/><ping rd=\"3866\" ping_freshness=\"{742df5ae-77cd-4b77-89fe-f6b4629a22e3}\"/><packages><package fp=\"1.7bfaaaf86917c1d6ebc1c794c849d6eb6a267e241af6a46cbb8929e24c2ab007\"/></packages></app><app appid=\"gkmgaooipdjhmangpemjhigmamcehddo\" version=\"20.115.3\" brand=\"GGRV\" cohort=\"1:gcf:\" cohortname=\"Stable\"><updatecheck/><ping rd=\"3866\" ping_freshness"
		"=\"{64ace7d8-3f75-4dc6-a74f-686e7f66579b}\"/><packages><package fp=\"1.8e0bf59ced78f557e82869bb165aba1365a34853c9d27f12a92d658a74c4561b\"/></packages></app><app appid=\"hnimpnehoodheedghdeeijklkeaacbdc\" version=\"0.57.44.2492\" brand=\"GGRV\"><updatecheck/><ping rd=\"3866\" ping_freshness=\"{c708ea61-2a90-4a9f-abe3-571f188811e8}\"/><packages><package fp=\"1.1cd7dc2056afaa0f6a705c9a17d22bba6578b33f5dae9e2d6518a0bfcced2396\"/></packages></app><app appid=\"hfnkpimlhhgieaddgfemjhofmfblmnib\" version="
		"\"3889\" brand=\"GGRV\" cohort=\"1:jcl:\" cohortname=\"Auto\"><updatecheck/><ping rd=\"3866\" ping_freshness=\"{5ef7cdb9-37bf-41f3-851d-b917fee81e61}\"/></app><app appid=\"npdjjkjlcidkjlamlmmdelcjbcpdjocm\" version=\"0.0.0.0\" brand=\"GGRV\"><updatecheck/><ping rd=\"3866\" ping_freshness=\"{ec623023-2573-44cc-9120-ad6d454ceb0b}\"/></app></request>", 
		"LAST");

	lr_end_transaction("Select Item",2);


	lr_start_transaction("Specials");

	web_add_cookie("__ar_v4=67Z3BVRYOFFZNC5W3YD4VA%3A20170801%3A8%7CHQ6BLEGB2BA6TKZMMKXFGZ%3A20170801%3A8%7CPOB5OBOK7ZAQLPZH64IM7W%3A20170801%3A8; DOMAIN=www.bcf.com.au");
	web_add_cookie("_uetsid=_uet4373206d; DOMAIN=www.bcf.com.au");
	web_add_cookie("bn_ec="
		"%7B%22a%22%3A%22c%22%2C%22c%22%3A%22d%26g%26s%22%2C%22d%22%3A%22http%3A%2F%2Fwww.bcf.com.au%2F%22%2C%22r%22%3A%22%22%2C%22t%22%3A1501735452584%2C%22u%22%3A%226926840889199666601%22%2C%22at%22%3A%7B%22StoreLocation%22%3A%22id%3D328%26name%3DBCF%20Auburn%26state%3DNSW%26link%3D%2FStores%2FBCF-Auburn%2F328%26regional%3Dfalse%26version%3D1.1%22%7D%2C%22trackingData%22%3Anull%2C%22dd%22%3A%22http%3A%2F%2Fwww.bcf.com.au%2Fstore%2Fmanagers-specials%2F5041506%22%2C%22de%22%3A%7B%22ti%22%3A%22Boating%2C%20"
		"Camping%20and%20Fishing%20Store%20Online%20-%20BCF%20Australia%22%2C%22nw%22%3A133%2C%22nl%22%3A920%7D%7D; DOMAIN=www.bcf.com.au");


	web_reg_find("Text=Managers Specials - BCF Australia",
		"LAST");

	web_url("5041506", 
		"URL=http://www.bcf.com.au/store/managers-specials/5041506", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.bcf.com.au/", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=http://dev.visualwebsiteoptimizer.com/j.php?a=131227&u=http%3A%2F%2Fwww.bcf.com.au%2Fstore%2Fmanagers-specials%2F5041506&r=0.17706093563269465", "ENDITEM", 
		"Url=http://dev.visualwebsiteoptimizer.com/v.gif?a=131227&d=bcf.com.au&u=4C624E2E1F547F5A5765D166AC9EEB67&h=d1ee0b04db032ad85a417da05b61068a&t=false&r=0.03399004385447757", "ENDITEM", 
		"Url=/authentication/get", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/bcf/images/thumbs/303103-thumb.jpg", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/bcf/images/thumbs/306059-thumb.jpg", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/bcf/images/thumbs/342448-thumb.jpg", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/bcf/images/thumbs/351730-thumb.jpg", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/bcf/images/thumbs/356574-thumb.jpg", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/bcf/images/thumbs/356604-thumb.jpg", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/bcf/images/thumbs/351737-thumb.jpg", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/bcf/images/thumbs/356571-thumb.jpg", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/bcf/images/thumbs/351748-thumb.jpg", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/bcf/images/thumbs/388110-thumb.jpg", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/bcf/images/thumbs/396374-thumb.jpg", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/bcf/images/thumbs/396377-thumb.jpg", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/bcf/images/thumbs/405314-thumb.jpg", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/bcf/images/thumbs/519576-thumb.jpg", "ENDITEM", 
		"Url=/Stores/GetNearest", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/bcf/images/thumbs/346057-thumb.jpg", "ENDITEM", 
		"Url=http://media.supercheapauto.com.au/shared/images/thumbs/346634-thumb.jpg", "ENDITEM", 
		"LAST");

	web_add_cookie("__utmb=169374002.2.10.1501735149; DOMAIN=www.bcf.com.au");
	web_add_cookie("__ssid=975ece51-7264-44ba-8853-40d4f13738ff; DOMAIN=configaus2.veinteractive.com");
	web_add_cookie("__cfduid=d5ac7d722d07c06248b3936e17baf70891501715111; DOMAIN=cdn.widgets.webengage.com");
	
	web_reg_find("Text=BonusBuyList", "LAST");

	web_custom_request("GetCart_2", 
		"URL=http://www.bcf.com.au/ShoppingCart/GetCart", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://www.bcf.com.au/store/managers-specials/5041506", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"plu\":null,\"quantity\":null,\"sourceID\":null}", 
		"EXTRARES", 
		"Url=http://a.adroll.com/j/roundtrip.js", "Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", "ENDITEM", 
		"Url=http://configaus2.veinteractive.com/tags/D68C87B5/ACC6/4F3B/B86D/AB8A8F17ECB8/tag.js", "Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", "ENDITEM", 
		"Url=http://cdn.widgets.webengage.com/js/widget/webengage-min-v-5.0.js", "Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", "ENDITEM", 
		"LAST");

	web_add_cookie("uid=e6f86d60-cb67-4f0d-a454-6472c28600d0; DOMAIN=widget.criteo.com");
	web_add_cookie("zdi="
		"*1uksl2%2fWjOctRKdwn1yoRwUe7u%2fyyyKHlirMCZh7AuncRAqJ9d2wWw5gXCYq8hxbtV851xpblyajprjL9QQrajNCoAGLweq2629O9N7JCTy6SOjqDtzOaUh8pismPw8CkvG3Edo8ttR3yHgzKgTxbr6O08sB3Iowj98xUNBBIWEnTMImdWjOikRCgx%2fYNnNqV%2fK8XrQz5E68pDpkxIdcl%2fKtL8gGHzBuoH2lrLk2bA2GzubjdqGf4c%2bq1QBj%2fmIhi5mXHHmwxL1mmdggXz37f1ZXn%2bYijHecx1u4gzJU7n11nJruY4XNcHJxgN%2fCBm2m4T0zHesICobhaDdYxo1tLvkezGEKMdjdYXQjCvp1L%2fMCao%2bRbUIilZasZCureR2lnDi37x%2fjUeWPqeFswQKGIPu1I0N3bUlXyRLVB3t9ucs39kg0DnHf1%2fz1P97GzFjqGdU37qAi8GE1jVFNmNAReGOwNKt"
		"1koGFZvDE6wxWSIlDEWW%2b69MVknfCXCFrXoIdzuua5WZHpajqmRovP%2bb6bw5JBxqmPDEFYnM5S1Wa1%2b3k%2fyn6QRekI%2fMVYSDglv5fgteC%2brF1VDT5uOpfftvxlQjEQux8IOATS7%2bELt0zri%2bLrEX%2b64DCdGKE09V0bwoV5m6A1O%2fDDXCuA9%2bg6kEcH2t5uc4tyMgU7MbzdVb79qjjx23KGFqQNn6itgYBpNhLUIq16epPS22vaPQ8arymNrS41zCRYo9WF66cx4fnvsCjavJKvEl9%2fx7Kq0%2bREBjdkqHRqyb6EZyWmvQ7Rq1JofboMFOlE9qRN2gvwMMSgsu76Okrn3YLsOyEWxkjOLfQZC6N%2bxUGLZuypSExhClHKCSsjYpdKcIm0H0TET4ojBZn0tNAiyIJqdCi94qniEY6P2dYdDz8GxN6fQK2S%2fCoTU%2b3qCkyfXa0XUaNvpNE6tpX5dVlN"
		"NTqXZrrYHcxoVMIBgRSJmSJJIp1zBWqF5VyL%2fAOvE6V4WO22aRSxXXu4xm91OypHt850z6HoxWU5r6DwPM%2bOUGSDg0%2fzp6WQ0dAR%2bnbSdnwp4yCk%2fW5Ch89LhnbZvElTL6CRhILqK0xBVnJOOJoF0pIlG0U2ZTwFtGJ3%2fps2k3YrsPhCPl5gudPmxjNPZg6wu5weMqk41JtTL%2bQTsDrkebSfiRu9yqJnPTxZYz7762qwZsjeZ3FGJ55lpIk5wSh7FwP4TJumDsGqGN9lMaEAaJFjs%2f5nFqTfBotSnX%2bLhNN28DHQ3akKO3Wc8%2bYvSWMBt8GtwwhBlSCHn9w%2fGuWEMZ%2bYTVRAM16%2bUqFCgA%3d%3d; DOMAIN=widget.criteo.com");
	web_add_cookie("eid=*1joMPgimUe8jyhej2AQhZ0bonJGd0uXQ599NEU7Wm4pcik0AlDos64NS%2fBhHz2WWgCtmlaija7TP00hYkj7KJ7CeIHqml8qWdLZso8BSlN%2bJOFcBRXLpWTTYkcrmIzR6fyiZ89Rx%2bl%2bkjfggNcC%2bLJR%2bMxqSDkASTGtV1BrsxuWqXzRcgFt9q7vgYbngaBVw5; DOMAIN=widget.criteo.com");

	 
	
	web_url("0_2",
		"URL=http://bat.bing.com/action/0?ti=5256926&Ver=2&mid=e50a2720-07d2-14d1-857c-d773693401ec&evt=pageLoad&sid=4373206d-0&lt=2362&pi=-1898162245&lg=en-GB&sw=1500&sh=1000&sc=24&r=http%3A%2F%2Fwww.bcf.com.au%2F&tl=Managers%20Specials%20-%20BCF%20Australia&kw=Managers%20Specials&p=http%3A%2F%2Fwww.bcf.com.au%2Fstore%2Fmanagers-specials%2F5041506%3Fpage%3D1%26pageSize%3D24%26sort%3D-ProductSummaryPurchasesWeighted%252C-ProductSummaryPurchases&rn=702362", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=http://widget.criteo.com/event?a=23025&v=4.4.1&p0=e%3Dexd%26site_type%3Dd&p1=e%3Dce%26m%3D%255B%255D&p2=e%3Dvl%26p%3D%255B112125%252C112149%252C112175%255D&p3=e%3Ddis&adce=1", "Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", "ENDITEM", 
		"Url=http://configaus2.veinteractive.com/scripts/5.0/capture-apps-5.0.0.js", "Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", "ENDITEM", 
		"LAST");

	 

	web_add_cookie("fr=0rcaRjSoaDfqvrL8c..BZglo2...1.0.BZglo2.; DOMAIN=www.facebook.com");

	web_reg_find("Text=var startstamp = new Date()", "LAST");

	web_url("cse_3", 
		"URL=http://connexity.net/c/cse?a=S&A=232&D=576d&V=10&R=1500x1000c24&T=6e&I0k=prodid&I0v=%23%23INSERT_PRODUCT_ID%23%23&J=http%3A%2F%2Fwww.bcf.com.au%2Fstore%2Fmanagers-specials%2F5041506%3Fpage%3D1%26pageSize%3D24%26sort%3D-ProductSummaryPurchasesWeighted%252C-ProductSummaryPurchases&b=5610", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=https://www.facebook.com/tr/?id=1515549495420397&ev=Search&cd[content_type]=product&cd[content_ids]=%5B%22794%22%2C%22791%22%2C%22789%22%5D&cd[product_catalog_id]=953521088036377&cd[product_category]=0&cd[criteo_audience_3_0]=A3&cd[external_id]=e6f86d60-cb67-4f0d-a454-6472c28600d0&cd[application_id]=423936147658676", "Referer=", "ENDITEM", 
		"Url=https://www.facebook.com/tr/?id=923391787702806&ev=PageView&dl=http%3A%2F%2Fwww.bcf.com.au%2Fstore%2Fmanagers-specials%2F5041506%3Fpage%3D1%26pageSize%3D24%26sort%3D-ProductSummaryPurchasesWeighted%252C-ProductSummaryPurchases&rl=http%3A%2F%2Fwww.bcf.com.au%2F&if=false&ts=1501735465509&v=2.7.19&ec=0&o=28", "Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", "ENDITEM", 
		"LAST");

	web_add_cookie("uid=e6f86d60-cb67-4f0d-a454-6472c28600d0; DOMAIN=dis.as.criteo.com");

	web_add_cookie("zdi="
		"*1uksl2%2fWjOctRKdwn1yoRwUe7u%2fyyyKHlirMCZh7AuncRAqJ9d2wWw5gXCYq8hxbtV851xpblyajprjL9QQrajNCoAGLweq2629O9N7JCTy6SOjqDtzOaUh8pismPw8CkvG3Edo8ttR3yHgzKgTxbr6O08sB3Iowj98xUNBBIWEnTMImdWjOikRCgx%2fYNnNqV%2fK8XrQz5E68pDpkxIdcl%2fKtL8gGHzBuoH2lrLk2bA2GzubjdqGf4c%2bq1QBj%2fmIhi5mXHHmwxL1mmdggXz37f1ZXn%2bYijHecx1u4gzJU7n11nJruY4XNcHJxgN%2fCBm2m4T0zHesICobhaDdYxo1tLvkezGEKMdjdYXQjCvp1L%2fMCao%2bRbUIilZasZCureR2lnDi37x%2fjUeWPqeFswQKGIPu1I0N3bUlXyRLVB3t9ucs39kg0DnHf1%2fz1P97GzFjqGdU37qAi8GE1jVFNmNAReGOwNKt"
		"1koGFZvDE6wxWSIlDEWW%2b69MVknfCXCFrXoIdzuua5WZHpajqmRovP%2bb6bw5JBxqmPDEFYnM5S1Wa1%2b3k%2fyn6QRekI%2fMVYSDglv5fgteC%2brF1VDT5uOpfftvxlQjEQux8IOATS7%2bELt0zri%2bLrEX%2b64DCdGKE09V0bwoV5m6A1O%2fDDXCuA9%2bg6kEcH2t5uc4tyMgU7MbzdVb79qjjx23KGFqQNn6itgYBpNhLUIq16epPS22vaPQ8arymNrS41zCRYo9WF66cx4fnvsCjavJKvEl9%2fx7Kq0%2bREBjdkqHRqyb6EZyWmvQ7Rq1JofboMFOlE9qRN2gvwMMSgsu76Okrn3YLsOyEWxkjOLfQZC6N%2bxUGLZuypSExhClHKCSsjYpdKcIm0H0TET4ojBZn0tNAiyIJqdCi94qniEY6P2dYdDz8GxN6fQK2S%2fCoTU%2b3qCkyfXa0XUaNvpNE6tpX5dVlN"
		"NTqXZrrYHcxoVMIBgRSJmSJJIp1zBWqF5VyL%2fAOvE6V4WO22aRSxXXu4xm91OypHt850z6HoxWU5r6DwPM%2bOUGSDg0%2fzp6WQ0dAR%2bnbSdnwp4yCk%2fW5Ch89LhnbZvElTL6CRhILqK0xBVnJOOJoF0pIlG0U2ZTwFtGJ3%2fps2k3YrsPhCPl5gudPmxjNPZg6wu5weMqk41JtTL%2bQTsDrkebSfiRu9yqJnPTxZYz7762qwZsjeZ3FGJ55lpIk5wSh7FwP4TJumDsGqGN9lMaEAaJFjs%2f5nFqTfBotSnX%2bLhNN28DHQ3akKO3Wc8%2bYvSWMBt8GtwwhBlSCHn9w%2fGuWEMZ%2bYTVRAM16%2bUqFCgA%3d%3d; DOMAIN=dis.as.criteo.com");
	web_add_cookie("eid=*1joMPgimUe8jyhej2AQhZ0bonJGd0uXQ599NEU7Wm4pcik0AlDos64NS%2fBhHz2WWgCtmlaija7TP00hYkj7KJ7CeIHqml8qWdLZso8BSlN%2bJOFcBRXLpWTTYkcrmIzR6fyiZ89Rx%2bl%2bkjfggNcC%2bLJR%2bMxqSDkASTGtV1BrsxuWqXzRcgFt9q7vgYbngaBVw5; DOMAIN=dis.as.criteo.com");

	web_reg_find("Text=Dising", "LAST");

	web_url("dis.aspx", 
		"URL=http://dis.as.criteo.com/dis/dis.aspx?p=23025&cb=97166911719&ref=http%3A%2F%2Fwww.bcf.com.au%2F&sc_r=1500x1000&sc_d=24", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"LAST");

	 
	web_reg_find("Text=proxygen", "Search=Headers", "LAST");
	web_submit_data("tr", 
		"Action=https://www.facebook.com/tr/", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=image/gif", 
		"Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=id", "Value=923391787702806", "ENDITEM", 
		"Name=ev", "Value=Microdata", "ENDITEM", 
		"Name=dl", "Value=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", "ENDITEM", 
		"Name=rl", "Value=http://www.bcf.com.au/", "ENDITEM", 
		"Name=if", "Value=false", "ENDITEM", 
		"Name=ts", "Value=1501735465515", "ENDITEM", 
		"Name=cd[Schema.org]", "Value=[{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$169.00\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$369.00\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$249.00\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$299.00\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\""
		"priceCurrency\":\"AUD\",\"price\":\"$235.00\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$49.99\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$43.99\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$76.99\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$280.00\"}},{\"type\":\"http://schema.org/Offer\",\""
		"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$76.99\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$199.00\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$299.00\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$29.00\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$79.99\"}},{\"type\":\"http://"
		"schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$309.00\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$19.00\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$169.00\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$9.99\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$229.00\"}},{\""
		"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$169.00\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$29.99\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$79.99\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\"$59.99\"}},{\"type\":\"http://schema.org/Offer\",\"properties\":{\"priceCurrency\":\"AUD\",\"price\":\""
		"$94.99\"}}]", "ENDITEM", 
		"Name=cd[OpenGraph]", "Value={}", "ENDITEM", 
		"Name=v", "Value=2.7.19", "ENDITEM", 
		"Name=o", "Value=28", "ENDITEM", 
		"LAST");

	web_add_cookie("__ssid=975ece51-7264-44ba-8853-40d4f13738ff; DOMAIN=appsapihk.veinteractive.com");
	web_add_cookie("__ssid=975ece51-7264-44ba-8853-40d4f13738ff; DOMAIN=cookiea1.veinteractive.com");

	web_reg_find("Text=nosniff", "Search=Headers", "LAST");
	web_url("iframeStorage-5.0.0.html", 
		"URL=https://configaus2.veinteractive.com/scripts/shared/iframeStorage-5.0.0.html?iframeid=ve-storage-iframe&journeyId=15309", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=https://s.adroll.com/pixel/67Z3BVRYOFFZNC5W3YD4VA/HQ6BLEGB2BA6TKZMMKXFGZ/POB5OBOK7ZAQLPZH64IM7W.js", "Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", "ENDITEM", 
		"Url=http://appsapihk.veinteractive.com/api/appsmanagerinit?isCookieEnabled=true&timeToLive=60&referrerDomain=http%3A%2F%2Fwww.bcf.com.au%2F&landingPage=http%3A%2F%2Fwww.bcf.com.au%2Fstore%2Fmanagers-specials%2F5041506%3Fpage%3D1%26pageSize%3D24%26sort%3D-ProductSummaryPurchasesWeighted%252C-ProductSummaryPurchases&journeyCode=D68C87B5-ACC6-4F3B-B86D-AB8A8F17ECB8&o=1989456844", "Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort="
		"-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", "ENDITEM", 
		"Url=http://cookiea1.veinteractive.com/api/SetCookie/D68C87B5-ACC6-4F3B-B86D-AB8A8F17ECB8?o=1989456844", "Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", "ENDITEM", 
		"LAST");

	web_add_cookie("D68C87B5-ACC6-4F3B-B86D-AB8A8F17ECB8=sessionId=%7B%22Features%22%3A%5B%7B%22Key%22%3A%22incrementality%22%2C%22Value%22%3A%22disabled.v1%22%7D%2C%7B%22Key%22%3A%22aa%22%2C%22Value%22%3A%22featureA.v1%22%7D%2C%7B%22Key%22%3A%22promocodeRequest%22%2C%22Value%22%3A%22getpromocode.v1%22%7D%2C%7B%22Key%22%3A%22recEngine%22%2C%22Value%22%3A%22recommendedProducts.v1%22%7D%5D%2C%22InactiveApps%22%3A%5B%5D%2C%22SessionId%22%3A%22919dbcd7-2d39-48d2-b3f8-ee501d10e90e%22%7D; DOMAIN="
		"appsapihk.veinteractive.com");

 
	web_url("appsmanagerinit", 
		"URL=http://appsapihk.veinteractive.com/api/appsmanagerinit?isCookieEnabled=true&timeToLive=60&referrerDomain=http%3A%2F%2Fwww.bcf.com.au%2F&landingPage=http%3A%2F%2Fwww.bcf.com.au%2Fstore%2Fmanagers-specials%2F5041506%3Fpage%3D1%26pageSize%3D24%26sort%3D-ProductSummaryPurchasesWeighted%252C-ProductSummaryPurchases&journeyCode=D68C87B5-ACC6-4F3B-B86D-AB8A8F17ECB8&o=1989456844", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=http://connexity.net/c/cse?a=R&A=232&C=0&D=576d&N=0-1a5b4f2dfc3023e4&R=1500x1000c24&T=6e&U=e9130e0e60a7f797-06221138786d19a9-211dc3652322137f&J=http%253a%252f%252fwww.bcf.com.au%252fstore%252fmanagers-specials%252f5041506%253fpage%253d1%2526pagesize%253d24%2526sort%253d-productsummarypurchasesweighted%252c-productsummarypurchases&V=10&I0k=prodid&I0v=%23%23INSERT_PRODUCT_ID%23%23&Q=v2.0.1,c:y,h5L:y,TS:(run:1ms),(Burl-R:233ms)", "Referer=http://connexity.net/c/cse?a=S&A=232&D=576d&V=10&R="
		"1500x1000c24&T=6e&I0k=prodid&I0v=%23%23INSERT_PRODUCT_ID%23%23&J=http%3A%2F%2Fwww.bcf.com.au%2Fstore%2Fmanagers-specials%2F5041506%3Fpage%3D1%26pageSize%3D24%26sort%3D-ProductSummaryPurchasesWeighted%252C-ProductSummaryPurchases&b=5610", "ENDITEM", 
		"LAST");

	web_reg_find("Text=End of DoubleClick Floodlight Tag", "LAST");

	web_url("cse_4", 
		"URL=http://connexity.net/c/cse?a=P&A=232&C=0&D=576d&N=0-1a5b4f2dfc3023e4&R=1500x1000c24&T=6e&U=e9130e0e60a7f797-06221138786d19a9-211dc3652322137f&J=http%253a%252f%252fwww.bcf.com.au%252fstore%252fmanagers-specials%252f5041506%253fpage%253d1%2526pagesize%253d24%2526sort%253d-productsummarypurchasesweighted%252c-productsummarypurchases&V=10&I0k=prodid&I0v=%23%23INSERT_PRODUCT_ID%23%23&Q=v2.0.1,c:y,h5L:y,TS:(run:1ms),(Burl-R:233ms),(Burl-P:233ms)", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://connexity.net/c/cse?a=S&A=232&D=576d&V=10&R=1500x1000c24&T=6e&I0k=prodid&I0v=%23%23INSERT_PRODUCT_ID%23%23&J=http%3A%2F%2Fwww.bcf.com.au%2Fstore%2Fmanagers-specials%2F5041506%3Fpage%3D1%26pageSize%3D24%26sort%3D-ProductSummaryPurchasesWeighted%252C-ProductSummaryPurchases&b=5610", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"LAST");

	web_add_cookie("sspid=8138b4fb-be31-4dc2-9b10-fd3629efc197; DOMAIN=sync.aralego.com");
	web_add_cookie("puids=j%3A%7B%22par-2EE948B3EA8B6A90994284DE3BE42B%22%3A%2224BC41CAC5114A719F54CB34E0E473F5%22%7D; DOMAIN=sync.aralego.com");

	web_reg_find("Text=goog-phish-shavar", "LAST");
	web_custom_request("gethash_2", 
		"URL=https://safebrowsing.google.com/safebrowsing/gethash?client=googlechrome&appver=60.0.3112.78&pver=3.0&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&ext=0", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"BodyBinary=4:4\nq\\xFEa~", 
		"EXTRARES", 
		"Url=http://sync.aralego.com/idSync/?ucf_nid=dsp-833DD22BEB97673FB4E8B8DBB882B99&ucf_user_id=e6f86d60-cb67-4f0d-a454-6472c28600d0", "Referer=", "ENDITEM", 
		"LAST");

	web_add_cookie("D68C87B5-ACC6-4F3B-B86D-AB8A8F17ECB8=sessionId=%7B%22Features%22%3A%5B%7B%22Key%22%3A%22incrementality%22%2C%22Value%22%3A%22disabled.v1%22%7D%2C%7B%22Key%22%3A%22aa%22%2C%22Value%22%3A%22featureA.v1%22%7D%2C%7B%22Key%22%3A%22promocodeRequest%22%2C%22Value%22%3A%22getpromocode.v1%22%7D%2C%7B%22Key%22%3A%22recEngine%22%2C%22Value%22%3A%22recommendedProducts.v1%22%7D%5D%2C%22InactiveApps%22%3A%5B%5D%2C%22SessionId%22%3A%22919dbcd7-2d39-48d2-b3f8-ee501d10e90e%22%7D; DOMAIN="
		"configaus2.veinteractive.com");

	web_url("mapuser", 
		"URL=http://usync.nexage.com/mapuser?providerid=10921&userid=e6f86d60-cb67-4f0d-a454-6472c28600d0", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=https://configaus2.veinteractive.com/scripts/shared/ifs-5.0.0.js", "Referer=https://configaus2.veinteractive.com/scripts/shared/iframeStorage-5.0.0.html?iframeid=ve-storage-iframe&journeyId=15309", "ENDITEM", 
		"LAST");

	web_add_cookie("criteo_uid=e6f86d60-cb67-4f0d-a454-6472c28600d0; DOMAIN=cosy.smaato.net");
	web_add_cookie("SomaCookieUserId=e0c8544c-9329-4d49-9d72-84e7a3cc5b6c; DOMAIN=cosy.smaato.net");
	web_add_cookie("KRTBCOOKIE_296=22788-e9130e0e60a7f797-06221138786d19a9; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KADUSERCOOKIE=A40C8ECC-3C15-4895-BD4F-81B0D2B9656D; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_153=19420-XevMvl2wwLRF5sO9C7fZ7QrrkO9F68y8WOEFfpD2; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_80=15669-CAESEGwuM-gUJsCydSK6C9M5AZk&KRTB&15671-CAESEGwuM-gUJsCydSK6C9M5AZk&KRTB&16514-CAESEGwuM-gUJsCydSK6C9M5AZk; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_699=22727-AACf2E6zBN8AAB0vrGPnRQ&KRTB&22744-AACf2E6zBN8AAB0vrGPnRQ; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_22=14911-pcv:1|uid:8754571067645666288&KRTB&16087-pcv:1|uid:8754571067645666288; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_27=16735-uid:d1085982-5b47-4400-9271-dae733dfdbc3&KRTB&16736-uid:d1085982-5b47-4400-9271-dae733dfdbc3; DOMAIN=image2.pubmatic.com");
	web_add_cookie("DPSync2=1504224000%3A102%7C1502236800%3A164%7C1501804800%3A174; DOMAIN=image2.pubmatic.com");
	web_add_cookie("SyncRTB2=1502928000%3A3_79_187_52_56_86_185_176_189_22_78%7C1504310400%3A93_54%7C1502582400%3A63%7C1504224000%3A46%7C1501891200%3A175%7C1502841600%3A71_8_21%7C1506902400%3A13%7C1502236800%3A2%7C1502323200%3A67; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_377=22918-ca96d5fa-336c-4901-b382-a584d69965e6; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_148=19421-uid:C8635177725A82596D658C3B02B86063; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_218=4056-WYJbSgAAAaPNrwIR&KRTB&22922-WYJbSgAAAaPNrwIR; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_1051=22884-18072662365551772391; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_1030=22848-bGHQ6KQbatw4; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_993=22625-5ce28ac1f2114f63e00f27ca5af66ad3; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_372=6575-uid:k8DQf-7OhzliK69nkYQlje2t5N0&KRTB&10110-uid:k8DQf-7OhzliK69nkYQlje2t5N0&KRTB&10662-uid:k8DQf-7OhzliK69nkYQlje2t5N0&KRTB&22875-uid:k8DQf-7OhzliK69nkYQlje2t5N0; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_330=22938-ac26677c4660bc0a70f6223e4fdbe374&KRTB&22939-ac26677c4660bc0a70f6223e4fdbe374&KRTB&22965-ac26677c4660bc0a70f6223e4fdbe374; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_963=20906-1jwne1xdj5vpo48r; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_646=22621-WYJbSgAAAaPNrwIR&KRTB&22649-WYJbSgAAAaPNrwIR; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_759=15681-026b7239a0524b059632f0fc; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_1074=22956-3dbfc46c-9d94-46ad-92a6-946dc0207376; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_466=16530-2009eef0-00f1-4af1-aea0-d6e46b88f966&KRTB&16532-2009eef0-00f1-4af1-aea0-d6e46b88f966; DOMAIN=image2.pubmatic.com");
	web_add_cookie("SPugT=1501720604; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_391=22924-3870852657608239364; DOMAIN=image2.pubmatic.com");
	web_add_cookie("TEMPHPAUSRBKCNT_0_0=0; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_18=15546-1038150097914301345&KRTB&22947-1038150097914301345; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KRTBCOOKIE_57=22767-4089286377946605836&KRTB&22776-4089286377946605836; DOMAIN=image2.pubmatic.com");
	web_add_cookie("PugT=1501729535; DOMAIN=image2.pubmatic.com");
	web_add_cookie("pubtime_184302=TMC; DOMAIN=image2.pubmatic.com");
	web_add_cookie("pubtime_70445=TMC; DOMAIN=image2.pubmatic.com");
	web_add_cookie("pubtime_61725=TMC; DOMAIN=image2.pubmatic.com");
	web_add_cookie("pubtime_61726=TMC; DOMAIN=image2.pubmatic.com");
	web_add_cookie("PMDTSHR=; DOMAIN=image2.pubmatic.com");
	web_add_cookie("PUBMDCID=4; DOMAIN=image2.pubmatic.com");
	web_add_cookie("pp=54495; DOMAIN=image2.pubmatic.com");
	web_add_cookie("KTPCACOOKIE=YES; DOMAIN=image2.pubmatic.com");
	web_add_cookie("pubfreq_61726=1908-2; DOMAIN=image2.pubmatic.com");
	web_add_cookie("c=1501715001; DOMAIN=x.bidswitch.net");
	web_add_cookie("tuuid=2009eef0-00f1-4af1-aea0-d6e46b88f966; DOMAIN=x.bidswitch.net");
	web_add_cookie("tuuid_last_update=1501715001; DOMAIN=x.bidswitch.net");
	web_add_cookie("JEB2=598267A36E650744240E742BFCCE823B; DOMAIN=ums.adtechjp.com");
	web_add_cookie("pd=v2|1501720699.114.8804.10.1.2.4.1.11.1.1.2|j5oz.or.9D9V9S9M9J9G.cagGefcHaK9P.9AeOajadaHcp.agaT.iDayhwa4cvcm.c7gCn1amaNaB.ndavaWdFezaE.fwen.hQf0lZb2izdt.ldh8; DOMAIN=jp-u.openx.net");
	web_add_cookie("p_synced=jt.9A.j5.ad.nt.aH.mL.b2.if.oz.or.aT.a4.dt.jN.aW.m7.jp.av.lx.ij.ib.hk.mP.e7.cp.gC.cH.np.ez.kr; DOMAIN=jp-u.openx.net");
	web_add_cookie("i=056d6201-8012-47fd-8ccb-f1fae6294f8b|1501715001; DOMAIN=jp-u.openx.net");

	web_reg_find("Text=criteo_uid=", "Search=Headers", "LAST");
	web_url("match", 
		"URL=http://cosy.smaato.net/criteo/match?criteo_uid=e6f86d60-cb67-4f0d-a454-6472c28600d0", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=http://image2.pubmatic.com/AdServer/Pug?vcode=bz0yJnR5cGU9MSZjb2RlPTMwMjMmdGw9MTI5NjAw&piggybackCookie=uid:e6f86d60-cb67-4f0d-a454-6472c28600d0", "Referer=", "ENDITEM", 
		"Url=https://x.bidswitch.net/sync?dsp_id=46&user_id=e6f86d60-cb67-4f0d-a454-6472c28600d0&expires=30", "Referer=", "ENDITEM", 
		"Url=http://agent.aralego.com/idSync/?ucf_nid=dsp-833DD22BEB97673FB4E8B8DBB882B99&ucf_user_id=e6f86d60-cb67-4f0d-a454-6472c28600d0", "Referer=", "ENDITEM", 
		"Url=http://ums.adtechjp.com/mapuser?providerid=1019;userid=e6f86d60-cb67-4f0d-a454-6472c28600d0", "Referer=", "ENDITEM", 
		"Url=http://jp-u.openx.net/w/1.0/sd?id=537072356&val=e6f86d60-cb67-4f0d-a454-6472c28600d0&c=jp", "Referer=", "ENDITEM", 
		"LAST");

	 

	web_add_cookie("uid=e6f86d60-cb67-4f0d-a454-6472c28600d0; DOMAIN=dis.criteo.com");
	web_add_cookie("zdi="
		"*1uksl2%2fWjOctRKdwn1yoRwUe7u%2fyyyKHlirMCZh7AuncRAqJ9d2wWw5gXCYq8hxbtV851xpblyajprjL9QQrajNCoAGLweq2629O9N7JCTy6SOjqDtzOaUh8pismPw8CkvG3Edo8ttR3yHgzKgTxbr6O08sB3Iowj98xUNBBIWEnTMImdWjOikRCgx%2fYNnNqV%2fK8XrQz5E68pDpkxIdcl%2fKtL8gGHzBuoH2lrLk2bA2GzubjdqGf4c%2bq1QBj%2fmIhi5mXHHmwxL1mmdggXz37f1ZXn%2bYijHecx1u4gzJU7n11nJruY4XNcHJxgN%2fCBm2m4T0zHesICobhaDdYxo1tLvkezGEKMdjdYXQjCvp1L%2fMCao%2bRbUIilZasZCureR2lnDi37x%2fjUeWPqeFswQKGIPu1I0N3bUlXyRLVB3t9ucs39kg0DnHf1%2fz1P97GzFjqGdU37qAi8GE1jVFNmNAReGOwNKt"
		"1koGFZvDE6wxWSIlDEWW%2b69MVknfCXCFrXoIdzuua5WZHpajqmRovP%2bb6bw5JBxqmPDEFYnM5S1Wa1%2b3k%2fyn6QRekI%2fMVYSDglv5fgteC%2brF1VDT5uOpfftvxlQjEQux8IOATS7%2bELt0zri%2bLrEX%2b64DCdGKE09V0bwoV5m6A1O%2fDDXCuA9%2bg6kEcH2t5uc4tyMgU7MbzdVb79qjjx23KGFqQNn6itgYBpNhLUIq16epPS22vaPQ8arymNrS41zCRYo9WF66cx4fnvsCjavJKvEl9%2fx7Kq0%2bREBjdkqHRqyb6EZyWmvQ7Rq1JofboMFOlE9qRN2gvwMMSgsu76Okrn3YLsOyEWxkjOLfQZC6N%2bxUGLZuypSExhClHKCSsjYpdKcIm0H0TET4ojBZn0tNAiyIJqdCi94qniEY6P2dYdDz8GxN6fQK2S%2fCoTU%2b3qCkyfXa0XUaNvpNE6tpX5dVlN"
		"NTqXZrrYHcxoVMIBgRSJmSJJIp1zBWqF5VyL%2fAOvE6V4WO22aRSxXXu4xm91OypHt850z6HoxWU5r6DwPM%2bOUGSDg0%2fzp6WQ0dAR%2bnbSdnwp4yCk%2fW5Ch89LhnbZvElTL6CRhILqK0xBVnJOOJoF0pIlG0U2ZTwFtGJ3%2fps2k3YrsPhCPl5gudPmxjNPZg6wu5weMqk41JtTL%2bQTsDrkebSfiRu9yqJnPTxZYz7762qwZsjeZ3FGJ55lpIk5wSh7FwP4TJumDsGqGN9lMaEAaJFjs%2f5nFqTfBotSnX%2bLhNN28DHQ3akKO3Wc8%2bYvSWMBt8GtwwhBlSCHn9w%2fGuWEMZ%2bYTVRAM16%2bUqFCgA%3d%3d; DOMAIN=dis.criteo.com");
	web_add_cookie("eid=*1joMPgimUe8jyhej2AQhZ0bonJGd0uXQ599NEU7Wm4pcik0AlDos64NS%2fBhHz2WWgCtmlaija7TP00hYkj7KJ7CeIHqml8qWdLZso8BSlN%2bJOFcBRXLpWTTYkcrmIzR6fyiZ89Rx%2bl%2bkjfggNcC%2bLJR%2bMxqSDkASTGtV1BrsxuWqXzRcgFt9q7vgYbngaBVw5; DOMAIN=dis.criteo.com");
	web_add_cookie("uid=8ae1bfe0-1ec5-408f-ae86-fa533307eed9; DOMAIN=as.amanad.adtdp.com");
	web_add_cookie("pr=ame; DOMAIN=as.amanad.adtdp.com");
	web_add_cookie("d2=2009eef0-00f1-4af1-aea0-d6e46b88f966; DOMAIN=as.amanad.adtdp.com");
	web_add_cookie("au=J5VMI4Y6-AQGF-10.35.220.173; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2249=CAESEG30bajMAnLDDvZWnPCm7Tg; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_3778=WYJbSgAAAaPNrwIR; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2676=3870852657608239364; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2307=ca96d5fa-336c-4901-b382-a584d69965e6; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_3876=4089286377946605836; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2238=244f10fc-9ab8-4e83-8647-ce06c1b2b4e6; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2974=6065523352678089753; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2313=R1B341_95F7E407_11BE81B6D; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2149=e6f86d60-cb67-4f0d-a454-6472c28600d0; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("ruid=570732e759825b43785897de03b22e^2^1501729404^2019071966; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("ses57=37664^3; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("vis57=37664^3; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("csi57=; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("csc57=; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("ses201=; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("vis201=71138^2; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("csi201=; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("csc201=; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("ses54=32534^1&37664^6; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("vis54=32534^1&37664^6; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("csi54=; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("csc54=; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("cd=false; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_1512=d1085982-5b47-4400-9271-dae733dfdbc3; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_1986=4089286377946605836; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_1523=SeIhs3du1DD2PM5; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_1185=8754571067645666288; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_4968=4089286377946605836; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2596=1038150097914301345; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2909=4b197c4b5a261035919921501294348a; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2395=Q5550069941835147683; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_3320=ac26677c4660bc0a70f6223e4fdbe374; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2687=e9130e0e60a7f797-06221138786d19a9; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_3838=11001AAC2F93825924001B0B02B5CEB6; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2950=6ba10c40-77d7-11e7-a327-005056a210c3; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2861=3bfae96d-77d8-11e7-8d0b-21a8f195a4c8; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_3956=00d6124f339ff4a359dcd601; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2271=uVZZB9CtD99nzBMD4_ZvkYtLKAM; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_1902=WnMWmFooGpJCfhmbDC8Dyw1zSslCcxaaX3kjYnyb; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2978=026b7239a0524b059632f0fc; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_3818=1jwne1x3j5vv1hj6; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_4114=AACf2E6zBN8AAB0vrGPnRQ; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_1994=w5i0nrgd6g65; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_3992=-NR62odJMi2GAJOdvT3v; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_3822=6449842131754743827; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("rpb=31956%3D1%267751%3D1%26109108%3D1%2631950%3D1%2618014%3D1%2613490%3D1%26183462%3D1%2614459%3D1%264212%3D1%264210%3D1%26103820%3D1%26123034%3D1%264940%3D1%2614240%3D1%26144598%3D1%2645562%3D1%266434%3D1%2614321%3D1%26101732%3D1%26191940%3D1%2617599%3D1%267430%3D1%2611581%3D1%26377322%3D1%264894%3D1%264939%3D1%26102160%3D1%267935%3D1%264222%3D1%2617149%3D1%268981%3D1%2613464%3D1; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("rpx="
		"31956%3D66499%2C0%2C1%2C%2C%267751%3D66496%2C0%2C0%2C%2C%26109108%3D66496%2C0%2C1%2C%2C%2631950%3D66496%2C0%2C1%2C%2C%2618014%3D66499%2C0%2C1%2C%2C%2613490%3D66499%2C0%2C1%2C%2C%26183462%3D66499%2C0%2C1%2C%2C%2614459%3D66499%2C0%2C0%2C%2C%264212%3D66499%2C0%2C0%2C%2C%264210%3D66499%2C0%2C1%2C%2C%26103820%3D66499%2C0%2C1%2C%2C%26123034%3D66499%2C0%2C1%2C%2C%264940%3D66499%2C0%2C1%2C%2C%2614240%3D66496%2C0%2C0%2C%2C%26144598%3D66499%2C0%2C1%2C%2C%2645562%3D66499%2C0%2C1%2C%2C%266434%3D66497%2C0%2C1%"
		"2C%2C%2614321%3D66496%2C0%2C1%2C%2C%26101732%3D66499%2C0%2C1%2C%2C%26191940%3D66496%2C0%2C1%2C%2C%2617599%3D66499%2C0%2C1%2C%2C%267430%3D66496%2C0%2C1%2C%2C%2611581%3D66499%2C0%2C1%2C%2C%26377322%3D66499%2C0%2C1%2C%2C%264894%3D66499%2C0%2C0%2C%2C%264939%3D66499%2C0%2C1%2C%2C%26102160%3D66499%2C0%2C1%2C%2C%267935%3D66499%2C0%2C1%2C%2C%264222%3D66499%2C0%2C0%2C%2C%2617149%3D66499%2C0%2C1%2C%2C%268981%3D66496%2C0%2C1%2C%2C%2613464%3D66499%2C0%2C1%2C%2C; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("put_2590=FeBRfx76bCcvF8aTwyG1POOZ; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("khaos=J5VMC7BC-3-61QH; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("ses15=37664^3&116298^1; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("vis15=32534^2&37664^3&116298^16; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("csi15=; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("csc15=; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("ses9=; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("vis9=116298^16; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("csi9=; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("csc9=; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("ses2=37664^6&116298^4; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("vis2=32534^1&37664^6&116298^19; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("csi2=; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("csc2=; DOMAIN=pixel.rubiconproject.com");
	web_add_cookie("appnexus=4089286377946605836; DOMAIN=cs.adingo.jp");
	web_add_cookie("mediamath=d1085982-5b47-4400-9271-dae733dfdbc3; DOMAIN=cs.adingo.jp");
	web_add_cookie("JEB2=598259776E65242F240E742BF70EB73A; DOMAIN=adserver.adtechus.com");
	web_add_cookie("ex=\"eyJhcHBuZXh1cyI6ICI0MDg5Mjg2Mzc3OTQ2NjA1ODM2In0=\"; DOMAIN=cw.addthis.com");
	web_add_cookie("na_id=2017080223080383899870371425; DOMAIN=cw.addthis.com");
	web_add_cookie("pdv=eyIxMTMiOiBbIjAiLCAiZTZmODZkNjAtY2I2Ny00ZjBkLWE0NTQtNjQ3MmMyODYwMGQwIl19; DOMAIN=cw.addthis.com");
	web_add_cookie("uid=59825a5f173a4c22; DOMAIN=cw.addthis.com");
	web_add_cookie("um=2JE*3h25C2mQt4099NSKsPTZL3|2JT!1ug5bQ7yF0tq-jK4oCmdYn|2KN*0AjN3YCHxewUp7Pwr1IHjC; DOMAIN=cw.addthis.com");
	web_add_cookie("na_tc=Y; DOMAIN=cw.addthis.com");
	web_add_cookie("ctag=192:1501806861|193:1501806861|130:1501806861|194:1501806861|195:1501806861|196:1501806861|133:1502930061|197:1501806861|134:1501806861|203:1501806861|205:1501806861|174:1501806861|206:1501806861|182:1501806861|185:1501806861|187:1501806861|188:1501806861|189:1501806861|190:1501806861|191:1501806861; DOMAIN=ap.lijit.com");
	web_add_cookie("ljtrtb="
		"eJyN0cFuFDEMBuB3mTOWnMR2HG47s7Psgtrtbgv0hpJJUm1BFNqibYV4d5I36CUH63Oc%2FP47WDe8H6bVfD1fLReXvPlRpLze3zylP%2Fvt8yrNw7uBpZHjLWTvbI42Axe2QCgRUsYCRqupxKU4p51r4yvCSedpAjcZBtLAMK5pA2pGXNsxCMu6WduvtoihlIqAWA1QbEcsESFLIUmqNYg0S6HZ9GF7kE%2BHFJ%2FP1Pt9qy0xSOYawTlZgAIaSE4tRFbKEtqs0vtt7x%2B3CLzaLr%2FOB7PML%2Fj5yzd786S%2Ft1eXSzOmEfVM7A2KF2IRsdp%2FZXtMKo6N997ySi0HWQvr5Ea0owqKa6ynmQ0qh%2FYATuSBCBGC9QZyLN65XHNaOuVGz3zCn493We6EWymE8PbsvHm7NdisQaeGW9g%2BGHJoHPWZ1J88j7A%2BvYzzPc27%2BeF1d%2Fy%2B%2F2rnpbrwsNvS%2FuPmeHu6"
		"SI9TH9tXlqKt6oLC4mxbmUUPwUQDWhPVmCo5S8O%2F%2F2Qikj8%3D; DOMAIN=ap.lijit.com");
	web_add_cookie("tpro=eJxNUMtuhDAM%2FBefI%2BTw2i2%2F0b1VVRQFA5FCggJUqlb8e52wi3qb8UzGnjwhbBNF6J7gNjsTdChgDr0yYffbya75D8XVBg8dlAXCISDSQDFaP36SjmZ6UJxX6L6%2BBSwxDNZRyrXehDkjiagWt7MFi%2FImoELV4pu0qFjP7C4AVZWxvPMaE5yjMUdcEItawBh1r1YzZWcjwAd%2FSg2%2FGsn3Z7OBZu2ywJ4Lpvu1OVP1btKMF7%2B%2BAwuUAvQQlZ4zY0mvVvtMOGay65Jxmw6crOsj%2BZTlQ05n%2Fy%2FlpnXJDn2eL%2B%2BqqtOw4vZKlu80yeSWW%2FC8UfXHy9P8%2B7DmOI4%2FvRJ50A%3D%3D; DOMAIN=ap.lijit.com");
	web_add_cookie("ljtrtb_refresh=false; DOMAIN=ap.lijit.com");
	web_add_cookie("ljtrtbexp=eJxdjrERgDAMA3dxncJy4gSxGsfupAFOLv9kvXwZ7ER6sHu4NwvF%2FiI9V7PUdEFjkv%2FBwD74dAxkM7gWRi%2FCqTny7wc3T%2BXB8n3xZfFF4TxKfylP6F7I3v0AU0M9pQ%3D%3D; DOMAIN=ap.lijit.com");
	web_add_cookie("ljt_reader=eae5787ea1bb30e76892d784dfb602b8; DOMAIN=ap.lijit.com");

	web_reg_find("Text=nginx", "Search=Headers", "LAST");
	web_url("us.nend.net",
		"URL=http://us.nend.net/?f=6c1d6142&i=e6f86d60-cb67-4f0d-a454-6472c28600d0", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=http://dis.criteo.com/dis/rtb/microad/cookiematch.aspx?maid=&cmps_error=3", "Referer=", "ENDITEM", 
		"Url=http://dis.criteo.com/dis/rtb/microad/cookiematch.aspx?maid=76050190a9db2a34c2c3d5cac14bca46", "Referer=", "ENDITEM", 
		"Url=http://dis.criteo.com/dis/rtb/rightmedia/cookiematch.aspx?xid=DMPwRclqUvNeEQItuEiaKOGs", "Referer=", "ENDITEM", 
		"Url=http://as.amanad.adtdp.com/v1/sync?dsp_id=4,5&uid=e6f86d60-cb67-4f0d-a454-6472c28600d0", "Referer=", "ENDITEM", 
		"Url=http://pixel.rubiconproject.com/tap.php?v=9019&nid=2325&put=e6f86d60-cb67-4f0d-a454-6472c28600d0&expires=30", "Referer=", "ENDITEM", 
		"Url=http://cs.adingo.jp/sync/?from=criteo&id=e6f86d60-cb67-4f0d-a454-6472c28600d0", "Referer=", "ENDITEM", 
		"Url=http://adserver.adtechus.com/bind?ckey1=criteo_au;cvalue1=1;expiresDays=30;adct=image/gif;misc=9a2a9144-1566-4057-b537-80719467237f", "Referer=", "ENDITEM", 
		"Url=http://cw.addthis.com/t.gif?pid=113&pdid=e6f86d60-cb67-4f0d-a454-6472c28600d0", "Referer=", "ENDITEM", 
		"Url=http://dis.criteo.com/dis/rtb/appnexus/cookiematch.aspx?appnxsid=4089286377946605836", "Referer=", "ENDITEM", 
		"Url=http://ap.lijit.com/retarget?a=a&r=rtb_criteo&pid=9&3pid=e6f86d60-cb67-4f0d-a454-6472c28600d0", "Referer=", "ENDITEM", 
		"LAST");

	
	web_reg_find("Text=<head>", "LAST");
	web_url("empty.html", 
		"URL=http://static.criteo.net/empty.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://dis.as.criteo.com/dis/dis.aspx?p=23025&cb=97166911719&ref=http%3A%2F%2Fwww.bcf.com.au%2F&sc_r=1500x1000&sc_d=24", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=http://dis.criteo.com/dis/rtb/google/cookiematch.aspx?id=&google_ula=913071,0", "Referer=", "ENDITEM", 
		"Url=https://connect.facebook.net/signals/config/1540538456192988?v=2.7.19", "Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", "ENDITEM", 
		"Url=https://www.facebook.com/tr/?id=1540538456192988&ev=ViewContent&cd[content_type]=product&cd[content_ids]=adroll_dummy_product_&cd[application_id]=321379434608647&cd[product_catalog_id]=895805880441761&cd[external_id]=zuFXq0KhXp_LxP5i5FIedA", "Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", "ENDITEM", 
		"Url=https://d.adroll.com/cm/f/out", "Referer=http://www.bcf.com.au/store/managers-specials/5041506?page=1&pageSize=24&sort=-ProductSummaryPurchasesWeighted%2C-ProductSummaryPurchases", "ENDITEM", 
		"Url=http://10.9.20.77:8008/ssdp/device-desc.xml", "Referer=", "ENDITEM", 
		"LAST");
	
	lr_end_transaction("Specials",2);


	lr_think_time(10);


	lr_start_transaction("Home");

	web_add_cookie("__ar_v4=POB5OBOK7ZAQLPZH64IM7W%3A20170801%3A9%7CHQ6BLEGB2BA6TKZMMKXFGZ%3A20170801%3A9%7C67Z3BVRYOFFZNC5W3YD4VA%3A20170801%3A9; DOMAIN=www.bcf.com.au");
	web_add_cookie("bn_ec="
		"%7B%22a%22%3A%22c%22%2C%22c%22%3A%22d%26g%26s%22%2C%22d%22%3A%22http%3A%2F%2Fwww.bcf.com.au%2F%22%2C%22r%22%3A%22%22%2C%22t%22%3A1501735535286%2C%22u%22%3A%226926840889199666601%22%2C%22at%22%3A%7B%22StoreLocation%22%3A%22id%3D328%26name%3DBCF%20Auburn%26state%3DNSW%26link%3D%2FStores%2FBCF-Auburn%2F328%26regional%3Dfalse%26version%3D1.1%22%7D%2C%22trackingData%22%3Anull%2C%22dd%22%3A%22http%3A%2F%2Fwww.bcf.com.au%2F%22%2C%22de%22%3A%7B%22ti%22%3A%22Boating%2C%20Camping%20and%20Fishing%20Store%20O"
		"nline%20-%20BCF%20Australia%22%2C%22nw%22%3A133%2C%22nl%22%3A920%7D%7D; DOMAIN=www.bcf.com.au");
	web_add_cookie("__utmb=169374002.3.10.1501735149; DOMAIN=www.bcf.com.au");
	web_add_cookie("D68C87B5-ACC6-4F3B-B86D-AB8A8F17ECB8=sessionId=%7B%22Features%22%3A%5B%7B%22Key%22%3A%22incrementality%22%2C%22Value%22%3A%22disabled.v1%22%7D%2C%7B%22Key%22%3A%22aa%22%2C%22Value%22%3A%22featureA.v1%22%7D%2C%7B%22Key%22%3A%22promocodeRequest%22%2C%22Value%22%3A%22getpromocode.v1%22%7D%2C%7B%22Key%22%3A%22recEngine%22%2C%22Value%22%3A%22recommendedProducts.v1%22%7D%5D%2C%22InactiveApps%22%3A%5B%5D%2C%22SessionId%22%3A%22919dbcd7-2d39-48d2-b3f8-ee501d10e90e%22%7D; DOMAIN="
		"cookiea1.veinteractive.com");

	web_reg_find("Text=Boating, Camping and Fishing Store Online - BCF Australia", 
		"LAST");

	web_url("www.bcf.com.au_2", 
		"URL=http://www.bcf.com.au/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.bcf.com.au/", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=http://dev.visualwebsiteoptimizer.com/j.php?a=131227&u=http%3A%2F%2Fwww.bcf.com.au%2F&r=0.7059448174793821", "ENDITEM", 
		"Url=http://dev.visualwebsiteoptimizer.com/v.gif?a=131227&d=bcf.com.au&u=4C624E2E1F547F5A5765D166AC9EEB67&h=d1ee0b04db032ad85a417da05b61068a&t=false&r=0.45836630562647285", "ENDITEM", 
		"Url=/authentication/get", "ENDITEM", 
		"Url=/Stores/GetNearest", "ENDITEM", 
		"Url=http://widget.criteo.com/event?a=23025&v=4.4.1&p0=e%3Dexd%26site_type%3Dm&p1=e%3Dvh&p2=e%3Ddis&adce=1", "ENDITEM", 
		"Url=http://appsapihk.veinteractive.com/api/appsmanagerinit?isCookieEnabled=true&timeToLive=60&referrerDomain=http%3A%2F%2Fwww.bcf.com.au%2F&landingPage=http%3A%2F%2Fwww.bcf.com.au%2F&journeyCode=D68C87B5-ACC6-4F3B-B86D-AB8A8F17ECB8&o=1989456844", "ENDITEM", 
		"Url=http://cookiea1.veinteractive.com/api/SetCookie/D68C87B5-ACC6-4F3B-B86D-AB8A8F17ECB8?o=1989456844", "ENDITEM", 
		"LAST");

	web_reg_find("Text=StoreLocationID", "LAST");
	web_custom_request("GetCart_3", 
		"URL=http://www.bcf.com.au/ShoppingCart/GetCart", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://www.bcf.com.au/", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"plu\":null,\"quantity\":null,\"sourceID\":null}", 
		"LAST");

	web_reg_find("Text=X-MSEdge-Ref", "Search=Headers", "LAST");
	web_url("0_3", 
		"URL=http://bat.bing.com/action/0?ti=5256926&Ver=2&mid=23e2cbfa-e84c-1a37-4c43-0d5fdb5c7e44&evt=pageLoad&sid=4373206d-0&lt=5114&pi=0&lg=en-GB&sw=400&sh=789&sc=24&r=http%3A%2F%2Fwww.bcf.com.au%2F&tl=Boating,%20Camping%20and%20Fishing%20Store%20Online%20-%20BCF%20Australia&kw=BCF,%20Boating,%20Camping%20and%20Fishing%20Store%20Online%20-%20BCF%20Australia&p=http%3A%2F%2Fwww.bcf.com.au%2F&rn=517245", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://www.bcf.com.au/", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		"LAST");

	 

	web_url("iframeStorage-5.0.0.html_2", 
		"URL=https://configaus2.veinteractive.com/scripts/shared/iframeStorage-5.0.0.html?iframeid=ve-storage-iframe&journeyId=15309", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.bcf.com.au/", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		"LAST");

	 
	web_reg_find("Text=window.setTimeout;function V", "LAST");
	web_url("cse_5", 
		"URL=http://connexity.net/c/cse?a=S&A=232&D=576d&V=10&R=400x789c24&T=6e&I0k=prodid&I0v=%23%23INSERT_PRODUCT_ID%23%23&J=http%3A%2F%2Fwww.bcf.com.au%2F&b=6651", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.bcf.com.au/", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		"LAST");

	web_reg_find("Text=Dising", "LAST");
	web_url("dis.aspx_2", 
		"URL=http://dis.as.criteo.com/dis/dis.aspx?p=23025&cb=70498436132&ref=http%3A%2F%2Fwww.bcf.com.au%2F&sc_r=400x789&sc_d=24&site_type=m", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.bcf.com.au/", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		"LAST");

	lr_end_transaction("Home",2);

	return 0;
}
# 5 "c:\\adminplanit\\vugen scripts\\bcfhtmlmobilechrome001\\\\combined_BCFHTMLMobileChrome001.c" 2

# 1 "vuser_end.c" 1
vuser_end()
{
	return 0;
}
# 6 "c:\\adminplanit\\vugen scripts\\bcfhtmlmobilechrome001\\\\combined_BCFHTMLMobileChrome001.c" 2

